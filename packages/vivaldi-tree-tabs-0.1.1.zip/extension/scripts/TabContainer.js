/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 13);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
exports.tabContainer = exports.TabContainer = void 0;
var Tab_1 = __webpack_require__(1);
var TabContainer = /** @class */ (function () {
    function TabContainer() {
        this.tabs = new Map();
    }
    TabContainer.prototype.add = function (tab) {
        this.tabs.set(tab.id, tab);
    };
    TabContainer.prototype.get = function (id) {
        var tab = this.tabs.get(id);
        if (!tab) {
            throw new Error('Invalid access for tab id' + id);
        }
        return tab;
    };
    TabContainer.prototype.applyAll = function (callback) {
        this.tabs.forEach(function (tab) { return callback(tab); });
    };
    TabContainer.prototype.getFirst = function () {
        return this.tabs.values().next().value;
    };
    TabContainer.prototype.remove = function (tab) {
        if (this.tabs.get(tab.id)) {
            this.tabs.delete(tab.id);
        }
    };
    TabContainer.prototype.isEmpty = function () {
        return this.tabs.size === 0;
    };
    // Create tabs and their relationships
    TabContainer.prototype.initFromArray = function (tabs) {
        var _this = this;
        var parentQueue = new Map();
        tabs.forEach(function (tab) {
            var tabObj = new Tab_1.default(tab);
            // Parent already in container -> set parent normally
            if (tab.openerTabId) {
                var parent_1 = _this.get(tab.openerTabId);
                if (parent_1) {
                    tabObj.parentTo(parent_1);
                }
                // Parent not yet in container. Wait for it to be created
                else {
                    if (!parentQueue.has(tab.openerTabId)) {
                        parentQueue.set(tab.openerTabId, []);
                    }
                    // should be just parentQueue.get(tab.openerTabId).push(tabObj)
                    var siblingparentQueue = parentQueue.get(tab.openerTabId);
                    if (siblingparentQueue) {
                        siblingparentQueue.push(tabObj);
                    }
                }
            }
            // Top level tab -> parent to window's root tab
            else {
                var window_1 = tabObj.getWindow();
                tabObj.parentTo(window_1.root);
            }
            var queueForThis = parentQueue.get(tabObj.id);
            if (queueForThis) {
                // Children were created first -> parent them
                queueForThis.forEach(function (tab) {
                    tab.parentTo(tabObj);
                });
            }
            _this.add(tabObj);
        });
    };
    return TabContainer;
}());
exports.TabContainer = TabContainer;
// Contains references to all tabs from each window
exports.tabContainer = new TabContainer();


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
var TabContainer_1 = __webpack_require__(0);
var Command_1 = __webpack_require__(2);
var WindowContainer_1 = __webpack_require__(3);
var Tab = /** @class */ (function () {
    function Tab(chromeTab) {
        if (chromeTab) {
            if (chromeTab.id) {
                this.id = chromeTab.id;
            }
            else {
                // "Under some circumstances a tab may not be assigned an ID for example,
                // when querying foreign tabs using the sessions API"
                // should never happen here
                throw new Error('No tab id');
            }
            this.chromeTab = chromeTab;
            this.initialIndex = chromeTab.index;
        }
        else {
            this.isRoot = true;
            this.id = 0;
        }
        this.children = new TabContainer_1.TabContainer();
        this.closeChildrenButtonVisible = false;
    }
    // Call function on every child (but not children of children)
    Tab.prototype.applyChildren = function (callback) {
        this.children.applyAll(callback);
    };
    // Call function on every descendant (children, children of children
    Tab.prototype.applyDescendants = function (callback) {
        this.children.tabs.forEach(function (tab) {
            callback(tab);
            return tab.applyDescendants(callback);
        });
    };
    // Send tab specific command to Browserhook
    Tab.prototype.command = function (command, parameters) {
        if (parameters === void 0) { parameters = {}; }
        parameters['tabId'] = this.id;
        var cmd = new Command_1.default(command, parameters);
        cmd.send(this.getWindow());
    };
    // Traverse to root, return distance / depth / indentlevel  **/
    /* eg:
      -a: root
         - b: distance to root: 1
         - c: distance to root: 1
           - d: distance to root: 2
    */
    Tab.prototype.calculateDistanceToRoot = function () {
        var helper = function (tab, distance) {
            if (tab.parent) {
                if (tab.parent.isRoot) {
                    return helper(tab.parent, distance);
                }
                else {
                    return helper(tab.parent, ++distance);
                }
            }
            else {
                return distance;
            }
        };
        return helper(this, 0);
    };
    Tab.prototype.depth = function () {
        return this.calculateDistanceToRoot();
    };
    Tab.prototype.getWindow = function () {
        var windowId = this.chromeTab.windowId;
        return WindowContainer_1.windowContainer.get(windowId);
    };
    Tab.prototype.parentTo = function (parent) {
        // Add tab to new parent's child list
        parent.children.add(this);
        this.parent = parent;
        // Has children now -> show close children button
        // if (!parent.isRoot && !parent.closeChildrenButtonVisible) {
        if (!parent.isRoot) {
            parent.showCloseChildrenButton();
        }
        return this;
    };
    // Remove tab and parent it's children to own parent
    Tab.prototype.remove = function () {
        var _this = this;
        // Parent removed tab's children to own parent and redraw
        this.applyDescendants(function (child) {
            // Reparent direct children
            if (child.parent.id === _this.id) {
                child.parentTo(_this.parent);
            }
            // Re-render all descendants since their indentation has changed,      // while parent stayed the same.
            child.renderIndentation();
        });
        this.parent.children.remove(this); // remove from parent's children
        // The last child was removed -> hide close children button
        if (!this.parent.isRoot && this.parent.children.isEmpty()) {
            this.parent.hideCloseChildrenButton();
        }
    };
    Tab.prototype.removeChildren = function () {
        this.applyDescendants(function (child) {
            chrome.tabs.remove(child.id);
            if (chrome.runtime.lastError) {
                console.log('Error on removeChildren');
            }
        });
    };
    // Called on each tab after tab container reappear is redrawn.
    Tab.prototype.renderEverything = function () {
        if (!this.children.isEmpty()) {
            this.command('ShowCloseChildrenButton');
        }
        this.renderIndentation();
    };
    Tab.prototype.showCloseChildrenButton = function () {
        this.command('ShowCloseChildrenButton');
        this.closeChildrenButtonVisible = true;
    };
    Tab.prototype.hideCloseChildrenButton = function () {
        this.command('HideCloseChildrenButton');
        this.closeChildrenButtonVisible = false;
    };
    Tab.prototype.renderIndentation = function () {
        var depth = this.depth();
        this.command('IndentTab', { 'indentLevel': depth });
    };
    return Tab;
}());
exports.default = Tab;


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var TabContainer_1 = __webpack_require__(0);
var Command = /** @class */ (function () {
    function Command(command, parameters) {
        this.command = command;
        this.parameters = parameters;
        this.logEnabled = true;
    }
    // Send command to window via Chrome external messaging API
    Command.prototype.send = function (window) {
        var parameters = __assign(__assign({}, this.parameters), { command: this.command });
        if (!window.isConnected()) {
            window.connect();
            if (!window.isConnected()) {
                console.error('Cant connect to window', window);
                return;
            }
        }
        var success = window.connection.sendMessage(parameters);
        if (!success) {
            console.error('Command couldn\'t be sent');
        }
        if (this.logEnabled) {
            console.table(parameters);
            var logLine = success ? 'Sent to' : 'Failed to send';
            console.log(logLine, window);
        }
    };
    // Commands received from browserhook
    Command.onReceived = function (request) {
        console.log('Command received', request);
        switch (request.command) {
            case 'CloseChildren':
                var tab = TabContainer_1.tabContainer.get(request.tabId);
                tab.removeChildren();
                break;
            case 'RenderAllTabs':
                TabContainer_1.tabContainer.applyAll(function (tab) { return tab.renderEverything(); });
                break;
            default:
                console.error('Unknown command: ' + request.command);
                break;
        }
    };
    return Command;
}());
exports.default = Command;


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
exports.windowContainer = void 0;
var Window_1 = __webpack_require__(4);
var WindowContainer = /** @class */ (function () {
    function WindowContainer() {
        this.windows = new Map();
    }
    WindowContainer.prototype.add = function (window) {
        var key = window.id;
        this.windows.set(key, window);
    };
    WindowContainer.prototype.get = function (id) {
        var window = this.windows.get(id);
        if (!window) {
            throw new Error('WindowContainer: access to missing element. id:  ' + id);
        }
        return window;
    };
    WindowContainer.prototype.remove = function (window) {
        this.windows.delete(window.id);
    };
    WindowContainer.prototype.initFromArray = function (windows) {
        var _this = this;
        windows.forEach(function (chromeWindow) {
            // connect() doesn't work here due to a race-condition with messaging.
            // Try connecting when the message-bridge is actually needed; Command#send()
            var window = Window_1.default.init(chromeWindow);
            _this.add(window);
        });
    };
    return WindowContainer;
}());
exports.windowContainer = new WindowContainer();


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
var Tab_1 = __webpack_require__(1);
var Connection_1 = __webpack_require__(5);
var Window = /** @class */ (function () {
    function Window(id, chromeWindow) {
        this.id = id;
        this.chromeWindow = chromeWindow;
        this.root = new Tab_1.default();
    }
    Window.init = function (chromeWindow) {
        return new Window(chromeWindow.id, chromeWindow);
    };
    // Open messaging port between browser window and extension
    Window.prototype.connect = function () {
        var portName = "window-" + this.id;
        this.connection = new Connection_1.default();
        this.connection.connect({ name: portName });
    };
    Window.prototype.onRemoved = function () {
        this.root.applyDescendants(function (tab) { return tab.remove(); });
    };
    Window.prototype.isConnected = function () {
        return this.connection !== undefined;
    };
    return Window;
}());
exports.default = Window;


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
var Command_1 = __webpack_require__(2);
var Connection = /** @class */ (function () {
    function Connection() {
        // Port is active after OK message is received from UserScript
        // and no disconnect event have been received
        this._isActive = false;
    }
    Object.defineProperty(Connection.prototype, "port", {
        get: function () {
            return this._port;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Connection.prototype, "isDisconnected", {
        get: function () {
            return this._isDisconnected;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Connection.prototype, "isActivE", {
        get: function () {
            return this._isActive;
        },
        enumerable: false,
        configurable: true
    });
    Connection.prototype.addListeners = function () {
        this.port.onDisconnect.addListener(this.onDisconnect);
        this.port.onMessage.addListener(this.onMessage);
    };
    Connection.prototype.onMessage = function (message, _port) {
        // TODO: Command parsing + definitions
        if (message == 'OK') {
            this._isActive = true;
        }
        else if (message == 'ACK' || message == 'NACK') {
            console.log('Extension reply : ' + message);
        }
        else if (message.command) {
            Command_1.default.onReceived(message);
        }
    };
    Connection.prototype.sendMessage = function (message) {
        this._port.postMessage(message);
        return chrome.runtime.lastError === undefined;
    };
    Connection.prototype.onDisconnect = function (port) {
        console.log('Port disconnected', port);
        this._isDisconnected = true;
        this._isActive = false;
    };
    // ConnectInfo is used to set port name
    // Current name format is: `window-<window.id>`
    // Name is used in user script to match messaging ports and browsing windows
    Connection.prototype.connect = function (info) {
        // Vivaldi's extension id. Probably shouldn't be hardcoded.
        var extId = 'mpognobbkildjkofajifpdfhcoklimli';
        this._port = chrome.runtime.connect(extId, info);
        if (chrome.runtime.lastError) {
            throw new Error('Connect failed to browser.html.'
                + 'Is browserhook installed? chrome.runtime.lastError: '
                + chrome.runtime.lastError);
        }
        else {
            this.addListeners();
        }
    };
    return Connection;
}());
exports.default = Connection;


/***/ }),
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(0);


/***/ })
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgMWQ3NWNhYWYzZDZmNWFhZDQ3M2MiLCJ3ZWJwYWNrOi8vLy4vYXBwL3NjcmlwdHMvVGFiQ29udGFpbmVyLnRzIiwid2VicGFjazovLy8uL2FwcC9zY3JpcHRzL1RhYi50cyIsIndlYnBhY2s6Ly8vLi9hcHAvc2NyaXB0cy9Db21tYW5kLnRzIiwid2VicGFjazovLy8uL2FwcC9zY3JpcHRzL1dpbmRvd0NvbnRhaW5lci50cyIsIndlYnBhY2s6Ly8vLi9hcHAvc2NyaXB0cy9XaW5kb3cudHMiLCJ3ZWJwYWNrOi8vLy4vYXBwL3NjcmlwdHMvQ29ubmVjdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLEtBQUs7UUFDTDtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOztRQUVBO1FBQ0E7Ozs7Ozs7QUM3REEsOENBQThDLGNBQWM7QUFDNUQ7QUFDQSxZQUFZLG1CQUFPLENBQUMsQ0FBTztBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQ0FBMEMsc0JBQXNCLEVBQUU7QUFDbEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTs7Ozs7OztBQzFFQSw4Q0FBOEMsY0FBYztBQUM1RCxxQkFBcUIsbUJBQU8sQ0FBQyxDQUFnQjtBQUM3QyxnQkFBZ0IsbUJBQU8sQ0FBQyxDQUFXO0FBQ25DLHdCQUF3QixtQkFBTyxDQUFDLENBQW1CO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxpQkFBaUI7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCwwQ0FBMEM7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsdUJBQXVCO0FBQzFEO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7Ozs7Ozs7QUNwSUE7QUFDQTtBQUNBLGdEQUFnRCxPQUFPO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBOEMsY0FBYztBQUM1RCxxQkFBcUIsbUJBQU8sQ0FBQyxDQUFnQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDLHFCQUFxQix3QkFBd0I7QUFDMUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFFQUFxRSwrQkFBK0IsRUFBRTtBQUN0RztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDs7Ozs7OztBQ3pEQSw4Q0FBOEMsY0FBYztBQUM1RDtBQUNBLGVBQWUsbUJBQU8sQ0FBQyxDQUFVO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUVBQXlFO0FBQ3pFO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLENBQUM7QUFDRDs7Ozs7OztBQ2hDQSw4Q0FBOEMsY0FBYztBQUM1RCxZQUFZLG1CQUFPLENBQUMsQ0FBTztBQUMzQixtQkFBbUIsbUJBQU8sQ0FBQyxDQUFjO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDLGlCQUFpQjtBQUNsRDtBQUNBO0FBQ0EsbURBQW1ELHFCQUFxQixFQUFFO0FBQzFFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7Ozs7Ozs7QUMxQkEsOENBQThDLGNBQWM7QUFDNUQsZ0JBQWdCLG1CQUFPLENBQUMsQ0FBVztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0QiLCJmaWxlIjoiVGFiQ29udGFpbmVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7XG4gXHRcdFx0XHRjb25maWd1cmFibGU6IGZhbHNlLFxuIFx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcbiBcdFx0XHRcdGdldDogZ2V0dGVyXG4gXHRcdFx0fSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gMTMpO1xuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIHdlYnBhY2svYm9vdHN0cmFwIDFkNzVjYWFmM2Q2ZjVhYWQ0NzNjIiwiT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy50YWJDb250YWluZXIgPSBleHBvcnRzLlRhYkNvbnRhaW5lciA9IHZvaWQgMDtcbnZhciBUYWJfMSA9IHJlcXVpcmUoXCIuL1RhYlwiKTtcbnZhciBUYWJDb250YWluZXIgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gVGFiQ29udGFpbmVyKCkge1xuICAgICAgICB0aGlzLnRhYnMgPSBuZXcgTWFwKCk7XG4gICAgfVxuICAgIFRhYkNvbnRhaW5lci5wcm90b3R5cGUuYWRkID0gZnVuY3Rpb24gKHRhYikge1xuICAgICAgICB0aGlzLnRhYnMuc2V0KHRhYi5pZCwgdGFiKTtcbiAgICB9O1xuICAgIFRhYkNvbnRhaW5lci5wcm90b3R5cGUuZ2V0ID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgIHZhciB0YWIgPSB0aGlzLnRhYnMuZ2V0KGlkKTtcbiAgICAgICAgaWYgKCF0YWIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBhY2Nlc3MgZm9yIHRhYiBpZCcgKyBpZCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRhYjtcbiAgICB9O1xuICAgIFRhYkNvbnRhaW5lci5wcm90b3R5cGUuYXBwbHlBbGwgPSBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgICAgICAgdGhpcy50YWJzLmZvckVhY2goZnVuY3Rpb24gKHRhYikgeyByZXR1cm4gY2FsbGJhY2sodGFiKTsgfSk7XG4gICAgfTtcbiAgICBUYWJDb250YWluZXIucHJvdG90eXBlLmdldEZpcnN0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy50YWJzLnZhbHVlcygpLm5leHQoKS52YWx1ZTtcbiAgICB9O1xuICAgIFRhYkNvbnRhaW5lci5wcm90b3R5cGUucmVtb3ZlID0gZnVuY3Rpb24gKHRhYikge1xuICAgICAgICBpZiAodGhpcy50YWJzLmdldCh0YWIuaWQpKSB7XG4gICAgICAgICAgICB0aGlzLnRhYnMuZGVsZXRlKHRhYi5pZCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFRhYkNvbnRhaW5lci5wcm90b3R5cGUuaXNFbXB0eSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudGFicy5zaXplID09PSAwO1xuICAgIH07XG4gICAgLy8gQ3JlYXRlIHRhYnMgYW5kIHRoZWlyIHJlbGF0aW9uc2hpcHNcbiAgICBUYWJDb250YWluZXIucHJvdG90eXBlLmluaXRGcm9tQXJyYXkgPSBmdW5jdGlvbiAodGFicykge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICB2YXIgcGFyZW50UXVldWUgPSBuZXcgTWFwKCk7XG4gICAgICAgIHRhYnMuZm9yRWFjaChmdW5jdGlvbiAodGFiKSB7XG4gICAgICAgICAgICB2YXIgdGFiT2JqID0gbmV3IFRhYl8xLmRlZmF1bHQodGFiKTtcbiAgICAgICAgICAgIC8vIFBhcmVudCBhbHJlYWR5IGluIGNvbnRhaW5lciAtPiBzZXQgcGFyZW50IG5vcm1hbGx5XG4gICAgICAgICAgICBpZiAodGFiLm9wZW5lclRhYklkKSB7XG4gICAgICAgICAgICAgICAgdmFyIHBhcmVudF8xID0gX3RoaXMuZ2V0KHRhYi5vcGVuZXJUYWJJZCk7XG4gICAgICAgICAgICAgICAgaWYgKHBhcmVudF8xKSB7XG4gICAgICAgICAgICAgICAgICAgIHRhYk9iai5wYXJlbnRUbyhwYXJlbnRfMSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIFBhcmVudCBub3QgeWV0IGluIGNvbnRhaW5lci4gV2FpdCBmb3IgaXQgdG8gYmUgY3JlYXRlZFxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXBhcmVudFF1ZXVlLmhhcyh0YWIub3BlbmVyVGFiSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnRRdWV1ZS5zZXQodGFiLm9wZW5lclRhYklkLCBbXSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLy8gc2hvdWxkIGJlIGp1c3QgcGFyZW50UXVldWUuZ2V0KHRhYi5vcGVuZXJUYWJJZCkucHVzaCh0YWJPYmopXG4gICAgICAgICAgICAgICAgICAgIHZhciBzaWJsaW5ncGFyZW50UXVldWUgPSBwYXJlbnRRdWV1ZS5nZXQodGFiLm9wZW5lclRhYklkKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNpYmxpbmdwYXJlbnRRdWV1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2libGluZ3BhcmVudFF1ZXVlLnB1c2godGFiT2JqKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFRvcCBsZXZlbCB0YWIgLT4gcGFyZW50IHRvIHdpbmRvdydzIHJvb3QgdGFiXG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB2YXIgd2luZG93XzEgPSB0YWJPYmouZ2V0V2luZG93KCk7XG4gICAgICAgICAgICAgICAgdGFiT2JqLnBhcmVudFRvKHdpbmRvd18xLnJvb3QpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIHF1ZXVlRm9yVGhpcyA9IHBhcmVudFF1ZXVlLmdldCh0YWJPYmouaWQpO1xuICAgICAgICAgICAgaWYgKHF1ZXVlRm9yVGhpcykge1xuICAgICAgICAgICAgICAgIC8vIENoaWxkcmVuIHdlcmUgY3JlYXRlZCBmaXJzdCAtPiBwYXJlbnQgdGhlbVxuICAgICAgICAgICAgICAgIHF1ZXVlRm9yVGhpcy5mb3JFYWNoKGZ1bmN0aW9uICh0YWIpIHtcbiAgICAgICAgICAgICAgICAgICAgdGFiLnBhcmVudFRvKHRhYk9iaik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfdGhpcy5hZGQodGFiT2JqKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICByZXR1cm4gVGFiQ29udGFpbmVyO1xufSgpKTtcbmV4cG9ydHMuVGFiQ29udGFpbmVyID0gVGFiQ29udGFpbmVyO1xuLy8gQ29udGFpbnMgcmVmZXJlbmNlcyB0byBhbGwgdGFicyBmcm9tIGVhY2ggd2luZG93XG5leHBvcnRzLnRhYkNvbnRhaW5lciA9IG5ldyBUYWJDb250YWluZXIoKTtcblxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vYXBwL3NjcmlwdHMvVGFiQ29udGFpbmVyLnRzXG4vLyBtb2R1bGUgaWQgPSAwXG4vLyBtb2R1bGUgY2h1bmtzID0gMCAxIDIgMyA0IDUgNiIsIk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbnZhciBUYWJDb250YWluZXJfMSA9IHJlcXVpcmUoXCIuL1RhYkNvbnRhaW5lclwiKTtcbnZhciBDb21tYW5kXzEgPSByZXF1aXJlKFwiLi9Db21tYW5kXCIpO1xudmFyIFdpbmRvd0NvbnRhaW5lcl8xID0gcmVxdWlyZShcIi4vV2luZG93Q29udGFpbmVyXCIpO1xudmFyIFRhYiA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBUYWIoY2hyb21lVGFiKSB7XG4gICAgICAgIGlmIChjaHJvbWVUYWIpIHtcbiAgICAgICAgICAgIGlmIChjaHJvbWVUYWIuaWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmlkID0gY2hyb21lVGFiLmlkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gXCJVbmRlciBzb21lIGNpcmN1bXN0YW5jZXMgYSB0YWIgbWF5IG5vdCBiZSBhc3NpZ25lZCBhbiBJRCBmb3IgZXhhbXBsZSxcbiAgICAgICAgICAgICAgICAvLyB3aGVuIHF1ZXJ5aW5nIGZvcmVpZ24gdGFicyB1c2luZyB0aGUgc2Vzc2lvbnMgQVBJXCJcbiAgICAgICAgICAgICAgICAvLyBzaG91bGQgbmV2ZXIgaGFwcGVuIGhlcmVcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIHRhYiBpZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5jaHJvbWVUYWIgPSBjaHJvbWVUYWI7XG4gICAgICAgICAgICB0aGlzLmluaXRpYWxJbmRleCA9IGNocm9tZVRhYi5pbmRleDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuaXNSb290ID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuaWQgPSAwO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuY2hpbGRyZW4gPSBuZXcgVGFiQ29udGFpbmVyXzEuVGFiQ29udGFpbmVyKCk7XG4gICAgICAgIHRoaXMuY2xvc2VDaGlsZHJlbkJ1dHRvblZpc2libGUgPSBmYWxzZTtcbiAgICB9XG4gICAgLy8gQ2FsbCBmdW5jdGlvbiBvbiBldmVyeSBjaGlsZCAoYnV0IG5vdCBjaGlsZHJlbiBvZiBjaGlsZHJlbilcbiAgICBUYWIucHJvdG90eXBlLmFwcGx5Q2hpbGRyZW4gPSBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgICAgICAgdGhpcy5jaGlsZHJlbi5hcHBseUFsbChjYWxsYmFjayk7XG4gICAgfTtcbiAgICAvLyBDYWxsIGZ1bmN0aW9uIG9uIGV2ZXJ5IGRlc2NlbmRhbnQgKGNoaWxkcmVuLCBjaGlsZHJlbiBvZiBjaGlsZHJlblxuICAgIFRhYi5wcm90b3R5cGUuYXBwbHlEZXNjZW5kYW50cyA9IGZ1bmN0aW9uIChjYWxsYmFjaykge1xuICAgICAgICB0aGlzLmNoaWxkcmVuLnRhYnMuZm9yRWFjaChmdW5jdGlvbiAodGFiKSB7XG4gICAgICAgICAgICBjYWxsYmFjayh0YWIpO1xuICAgICAgICAgICAgcmV0dXJuIHRhYi5hcHBseURlc2NlbmRhbnRzKGNhbGxiYWNrKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICAvLyBTZW5kIHRhYiBzcGVjaWZpYyBjb21tYW5kIHRvIEJyb3dzZXJob29rXG4gICAgVGFiLnByb3RvdHlwZS5jb21tYW5kID0gZnVuY3Rpb24gKGNvbW1hbmQsIHBhcmFtZXRlcnMpIHtcbiAgICAgICAgaWYgKHBhcmFtZXRlcnMgPT09IHZvaWQgMCkgeyBwYXJhbWV0ZXJzID0ge307IH1cbiAgICAgICAgcGFyYW1ldGVyc1sndGFiSWQnXSA9IHRoaXMuaWQ7XG4gICAgICAgIHZhciBjbWQgPSBuZXcgQ29tbWFuZF8xLmRlZmF1bHQoY29tbWFuZCwgcGFyYW1ldGVycyk7XG4gICAgICAgIGNtZC5zZW5kKHRoaXMuZ2V0V2luZG93KCkpO1xuICAgIH07XG4gICAgLy8gVHJhdmVyc2UgdG8gcm9vdCwgcmV0dXJuIGRpc3RhbmNlIC8gZGVwdGggLyBpbmRlbnRsZXZlbCAgKiovXG4gICAgLyogZWc6XG4gICAgICAtYTogcm9vdFxuICAgICAgICAgLSBiOiBkaXN0YW5jZSB0byByb290OiAxXG4gICAgICAgICAtIGM6IGRpc3RhbmNlIHRvIHJvb3Q6IDFcbiAgICAgICAgICAgLSBkOiBkaXN0YW5jZSB0byByb290OiAyXG4gICAgKi9cbiAgICBUYWIucHJvdG90eXBlLmNhbGN1bGF0ZURpc3RhbmNlVG9Sb290ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgaGVscGVyID0gZnVuY3Rpb24gKHRhYiwgZGlzdGFuY2UpIHtcbiAgICAgICAgICAgIGlmICh0YWIucGFyZW50KSB7XG4gICAgICAgICAgICAgICAgaWYgKHRhYi5wYXJlbnQuaXNSb290KSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBoZWxwZXIodGFiLnBhcmVudCwgZGlzdGFuY2UpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGhlbHBlcih0YWIucGFyZW50LCArK2Rpc3RhbmNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZGlzdGFuY2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBoZWxwZXIodGhpcywgMCk7XG4gICAgfTtcbiAgICBUYWIucHJvdG90eXBlLmRlcHRoID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5jYWxjdWxhdGVEaXN0YW5jZVRvUm9vdCgpO1xuICAgIH07XG4gICAgVGFiLnByb3RvdHlwZS5nZXRXaW5kb3cgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciB3aW5kb3dJZCA9IHRoaXMuY2hyb21lVGFiLndpbmRvd0lkO1xuICAgICAgICByZXR1cm4gV2luZG93Q29udGFpbmVyXzEud2luZG93Q29udGFpbmVyLmdldCh3aW5kb3dJZCk7XG4gICAgfTtcbiAgICBUYWIucHJvdG90eXBlLnBhcmVudFRvID0gZnVuY3Rpb24gKHBhcmVudCkge1xuICAgICAgICAvLyBBZGQgdGFiIHRvIG5ldyBwYXJlbnQncyBjaGlsZCBsaXN0XG4gICAgICAgIHBhcmVudC5jaGlsZHJlbi5hZGQodGhpcyk7XG4gICAgICAgIHRoaXMucGFyZW50ID0gcGFyZW50O1xuICAgICAgICAvLyBIYXMgY2hpbGRyZW4gbm93IC0+IHNob3cgY2xvc2UgY2hpbGRyZW4gYnV0dG9uXG4gICAgICAgIC8vIGlmICghcGFyZW50LmlzUm9vdCAmJiAhcGFyZW50LmNsb3NlQ2hpbGRyZW5CdXR0b25WaXNpYmxlKSB7XG4gICAgICAgIGlmICghcGFyZW50LmlzUm9vdCkge1xuICAgICAgICAgICAgcGFyZW50LnNob3dDbG9zZUNoaWxkcmVuQnV0dG9uKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbiAgICAvLyBSZW1vdmUgdGFiIGFuZCBwYXJlbnQgaXQncyBjaGlsZHJlbiB0byBvd24gcGFyZW50XG4gICAgVGFiLnByb3RvdHlwZS5yZW1vdmUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIC8vIFBhcmVudCByZW1vdmVkIHRhYidzIGNoaWxkcmVuIHRvIG93biBwYXJlbnQgYW5kIHJlZHJhd1xuICAgICAgICB0aGlzLmFwcGx5RGVzY2VuZGFudHMoZnVuY3Rpb24gKGNoaWxkKSB7XG4gICAgICAgICAgICAvLyBSZXBhcmVudCBkaXJlY3QgY2hpbGRyZW5cbiAgICAgICAgICAgIGlmIChjaGlsZC5wYXJlbnQuaWQgPT09IF90aGlzLmlkKSB7XG4gICAgICAgICAgICAgICAgY2hpbGQucGFyZW50VG8oX3RoaXMucGFyZW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFJlLXJlbmRlciBhbGwgZGVzY2VuZGFudHMgc2luY2UgdGhlaXIgaW5kZW50YXRpb24gaGFzIGNoYW5nZWQsICAgICAgLy8gd2hpbGUgcGFyZW50IHN0YXllZCB0aGUgc2FtZS5cbiAgICAgICAgICAgIGNoaWxkLnJlbmRlckluZGVudGF0aW9uKCk7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLnBhcmVudC5jaGlsZHJlbi5yZW1vdmUodGhpcyk7IC8vIHJlbW92ZSBmcm9tIHBhcmVudCdzIGNoaWxkcmVuXG4gICAgICAgIC8vIFRoZSBsYXN0IGNoaWxkIHdhcyByZW1vdmVkIC0+IGhpZGUgY2xvc2UgY2hpbGRyZW4gYnV0dG9uXG4gICAgICAgIGlmICghdGhpcy5wYXJlbnQuaXNSb290ICYmIHRoaXMucGFyZW50LmNoaWxkcmVuLmlzRW1wdHkoKSkge1xuICAgICAgICAgICAgdGhpcy5wYXJlbnQuaGlkZUNsb3NlQ2hpbGRyZW5CdXR0b24oKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgVGFiLnByb3RvdHlwZS5yZW1vdmVDaGlsZHJlbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5hcHBseURlc2NlbmRhbnRzKGZ1bmN0aW9uIChjaGlsZCkge1xuICAgICAgICAgICAgY2hyb21lLnRhYnMucmVtb3ZlKGNoaWxkLmlkKTtcbiAgICAgICAgICAgIGlmIChjaHJvbWUucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnRXJyb3Igb24gcmVtb3ZlQ2hpbGRyZW4nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICAvLyBDYWxsZWQgb24gZWFjaCB0YWIgYWZ0ZXIgdGFiIGNvbnRhaW5lciByZWFwcGVhciBpcyByZWRyYXduLlxuICAgIFRhYi5wcm90b3R5cGUucmVuZGVyRXZlcnl0aGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKCF0aGlzLmNoaWxkcmVuLmlzRW1wdHkoKSkge1xuICAgICAgICAgICAgdGhpcy5jb21tYW5kKCdTaG93Q2xvc2VDaGlsZHJlbkJ1dHRvbicpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMucmVuZGVySW5kZW50YXRpb24oKTtcbiAgICB9O1xuICAgIFRhYi5wcm90b3R5cGUuc2hvd0Nsb3NlQ2hpbGRyZW5CdXR0b24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMuY29tbWFuZCgnU2hvd0Nsb3NlQ2hpbGRyZW5CdXR0b24nKTtcbiAgICAgICAgdGhpcy5jbG9zZUNoaWxkcmVuQnV0dG9uVmlzaWJsZSA9IHRydWU7XG4gICAgfTtcbiAgICBUYWIucHJvdG90eXBlLmhpZGVDbG9zZUNoaWxkcmVuQnV0dG9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLmNvbW1hbmQoJ0hpZGVDbG9zZUNoaWxkcmVuQnV0dG9uJyk7XG4gICAgICAgIHRoaXMuY2xvc2VDaGlsZHJlbkJ1dHRvblZpc2libGUgPSBmYWxzZTtcbiAgICB9O1xuICAgIFRhYi5wcm90b3R5cGUucmVuZGVySW5kZW50YXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBkZXB0aCA9IHRoaXMuZGVwdGgoKTtcbiAgICAgICAgdGhpcy5jb21tYW5kKCdJbmRlbnRUYWInLCB7ICdpbmRlbnRMZXZlbCc6IGRlcHRoIH0pO1xuICAgIH07XG4gICAgcmV0dXJuIFRhYjtcbn0oKSk7XG5leHBvcnRzLmRlZmF1bHQgPSBUYWI7XG5cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL2FwcC9zY3JpcHRzL1RhYi50c1xuLy8gbW9kdWxlIGlkID0gMVxuLy8gbW9kdWxlIGNodW5rcyA9IDAgMSAyIDMgNCA1IDYiLCJ2YXIgX19hc3NpZ24gPSAodGhpcyAmJiB0aGlzLl9fYXNzaWduKSB8fCBmdW5jdGlvbiAoKSB7XG4gICAgX19hc3NpZ24gPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBzID0gYXJndW1lbnRzW2ldO1xuICAgICAgICAgICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApKVxuICAgICAgICAgICAgICAgIHRbcF0gPSBzW3BdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0O1xuICAgIH07XG4gICAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIFRhYkNvbnRhaW5lcl8xID0gcmVxdWlyZShcIi4vVGFiQ29udGFpbmVyXCIpO1xudmFyIENvbW1hbmQgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQ29tbWFuZChjb21tYW5kLCBwYXJhbWV0ZXJzKSB7XG4gICAgICAgIHRoaXMuY29tbWFuZCA9IGNvbW1hbmQ7XG4gICAgICAgIHRoaXMucGFyYW1ldGVycyA9IHBhcmFtZXRlcnM7XG4gICAgICAgIHRoaXMubG9nRW5hYmxlZCA9IHRydWU7XG4gICAgfVxuICAgIC8vIFNlbmQgY29tbWFuZCB0byB3aW5kb3cgdmlhIENocm9tZSBleHRlcm5hbCBtZXNzYWdpbmcgQVBJXG4gICAgQ29tbWFuZC5wcm90b3R5cGUuc2VuZCA9IGZ1bmN0aW9uICh3aW5kb3cpIHtcbiAgICAgICAgdmFyIHBhcmFtZXRlcnMgPSBfX2Fzc2lnbihfX2Fzc2lnbih7fSwgdGhpcy5wYXJhbWV0ZXJzKSwgeyBjb21tYW5kOiB0aGlzLmNvbW1hbmQgfSk7XG4gICAgICAgIGlmICghd2luZG93LmlzQ29ubmVjdGVkKCkpIHtcbiAgICAgICAgICAgIHdpbmRvdy5jb25uZWN0KCk7XG4gICAgICAgICAgICBpZiAoIXdpbmRvdy5pc0Nvbm5lY3RlZCgpKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignQ2FudCBjb25uZWN0IHRvIHdpbmRvdycsIHdpbmRvdyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHZhciBzdWNjZXNzID0gd2luZG93LmNvbm5lY3Rpb24uc2VuZE1lc3NhZ2UocGFyYW1ldGVycyk7XG4gICAgICAgIGlmICghc3VjY2Vzcykge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignQ29tbWFuZCBjb3VsZG5cXCd0IGJlIHNlbnQnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5sb2dFbmFibGVkKSB7XG4gICAgICAgICAgICBjb25zb2xlLnRhYmxlKHBhcmFtZXRlcnMpO1xuICAgICAgICAgICAgdmFyIGxvZ0xpbmUgPSBzdWNjZXNzID8gJ1NlbnQgdG8nIDogJ0ZhaWxlZCB0byBzZW5kJztcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGxvZ0xpbmUsIHdpbmRvdyk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8vIENvbW1hbmRzIHJlY2VpdmVkIGZyb20gYnJvd3Nlcmhvb2tcbiAgICBDb21tYW5kLm9uUmVjZWl2ZWQgPSBmdW5jdGlvbiAocmVxdWVzdCkge1xuICAgICAgICBjb25zb2xlLmxvZygnQ29tbWFuZCByZWNlaXZlZCcsIHJlcXVlc3QpO1xuICAgICAgICBzd2l0Y2ggKHJlcXVlc3QuY29tbWFuZCkge1xuICAgICAgICAgICAgY2FzZSAnQ2xvc2VDaGlsZHJlbic6XG4gICAgICAgICAgICAgICAgdmFyIHRhYiA9IFRhYkNvbnRhaW5lcl8xLnRhYkNvbnRhaW5lci5nZXQocmVxdWVzdC50YWJJZCk7XG4gICAgICAgICAgICAgICAgdGFiLnJlbW92ZUNoaWxkcmVuKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdSZW5kZXJBbGxUYWJzJzpcbiAgICAgICAgICAgICAgICBUYWJDb250YWluZXJfMS50YWJDb250YWluZXIuYXBwbHlBbGwoZnVuY3Rpb24gKHRhYikgeyByZXR1cm4gdGFiLnJlbmRlckV2ZXJ5dGhpbmcoKTsgfSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1Vua25vd24gY29tbWFuZDogJyArIHJlcXVlc3QuY29tbWFuZCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBDb21tYW5kO1xufSgpKTtcbmV4cG9ydHMuZGVmYXVsdCA9IENvbW1hbmQ7XG5cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL2FwcC9zY3JpcHRzL0NvbW1hbmQudHNcbi8vIG1vZHVsZSBpZCA9IDJcbi8vIG1vZHVsZSBjaHVua3MgPSAwIDEgMiAzIDQgNSA2IiwiT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy53aW5kb3dDb250YWluZXIgPSB2b2lkIDA7XG52YXIgV2luZG93XzEgPSByZXF1aXJlKFwiLi9XaW5kb3dcIik7XG52YXIgV2luZG93Q29udGFpbmVyID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFdpbmRvd0NvbnRhaW5lcigpIHtcbiAgICAgICAgdGhpcy53aW5kb3dzID0gbmV3IE1hcCgpO1xuICAgIH1cbiAgICBXaW5kb3dDb250YWluZXIucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uICh3aW5kb3cpIHtcbiAgICAgICAgdmFyIGtleSA9IHdpbmRvdy5pZDtcbiAgICAgICAgdGhpcy53aW5kb3dzLnNldChrZXksIHdpbmRvdyk7XG4gICAgfTtcbiAgICBXaW5kb3dDb250YWluZXIucHJvdG90eXBlLmdldCA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICB2YXIgd2luZG93ID0gdGhpcy53aW5kb3dzLmdldChpZCk7XG4gICAgICAgIGlmICghd2luZG93KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1dpbmRvd0NvbnRhaW5lcjogYWNjZXNzIHRvIG1pc3NpbmcgZWxlbWVudC4gaWQ6ICAnICsgaWQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB3aW5kb3c7XG4gICAgfTtcbiAgICBXaW5kb3dDb250YWluZXIucHJvdG90eXBlLnJlbW92ZSA9IGZ1bmN0aW9uICh3aW5kb3cpIHtcbiAgICAgICAgdGhpcy53aW5kb3dzLmRlbGV0ZSh3aW5kb3cuaWQpO1xuICAgIH07XG4gICAgV2luZG93Q29udGFpbmVyLnByb3RvdHlwZS5pbml0RnJvbUFycmF5ID0gZnVuY3Rpb24gKHdpbmRvd3MpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgd2luZG93cy5mb3JFYWNoKGZ1bmN0aW9uIChjaHJvbWVXaW5kb3cpIHtcbiAgICAgICAgICAgIC8vIGNvbm5lY3QoKSBkb2Vzbid0IHdvcmsgaGVyZSBkdWUgdG8gYSByYWNlLWNvbmRpdGlvbiB3aXRoIG1lc3NhZ2luZy5cbiAgICAgICAgICAgIC8vIFRyeSBjb25uZWN0aW5nIHdoZW4gdGhlIG1lc3NhZ2UtYnJpZGdlIGlzIGFjdHVhbGx5IG5lZWRlZDsgQ29tbWFuZCNzZW5kKClcbiAgICAgICAgICAgIHZhciB3aW5kb3cgPSBXaW5kb3dfMS5kZWZhdWx0LmluaXQoY2hyb21lV2luZG93KTtcbiAgICAgICAgICAgIF90aGlzLmFkZCh3aW5kb3cpO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIHJldHVybiBXaW5kb3dDb250YWluZXI7XG59KCkpO1xuZXhwb3J0cy53aW5kb3dDb250YWluZXIgPSBuZXcgV2luZG93Q29udGFpbmVyKCk7XG5cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL2FwcC9zY3JpcHRzL1dpbmRvd0NvbnRhaW5lci50c1xuLy8gbW9kdWxlIGlkID0gM1xuLy8gbW9kdWxlIGNodW5rcyA9IDAgMSAyIDMgNCA1IDYiLCJPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG52YXIgVGFiXzEgPSByZXF1aXJlKFwiLi9UYWJcIik7XG52YXIgQ29ubmVjdGlvbl8xID0gcmVxdWlyZShcIi4vQ29ubmVjdGlvblwiKTtcbnZhciBXaW5kb3cgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gV2luZG93KGlkLCBjaHJvbWVXaW5kb3cpIHtcbiAgICAgICAgdGhpcy5pZCA9IGlkO1xuICAgICAgICB0aGlzLmNocm9tZVdpbmRvdyA9IGNocm9tZVdpbmRvdztcbiAgICAgICAgdGhpcy5yb290ID0gbmV3IFRhYl8xLmRlZmF1bHQoKTtcbiAgICB9XG4gICAgV2luZG93LmluaXQgPSBmdW5jdGlvbiAoY2hyb21lV2luZG93KSB7XG4gICAgICAgIHJldHVybiBuZXcgV2luZG93KGNocm9tZVdpbmRvdy5pZCwgY2hyb21lV2luZG93KTtcbiAgICB9O1xuICAgIC8vIE9wZW4gbWVzc2FnaW5nIHBvcnQgYmV0d2VlbiBicm93c2VyIHdpbmRvdyBhbmQgZXh0ZW5zaW9uXG4gICAgV2luZG93LnByb3RvdHlwZS5jb25uZWN0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgcG9ydE5hbWUgPSBcIndpbmRvdy1cIiArIHRoaXMuaWQ7XG4gICAgICAgIHRoaXMuY29ubmVjdGlvbiA9IG5ldyBDb25uZWN0aW9uXzEuZGVmYXVsdCgpO1xuICAgICAgICB0aGlzLmNvbm5lY3Rpb24uY29ubmVjdCh7IG5hbWU6IHBvcnROYW1lIH0pO1xuICAgIH07XG4gICAgV2luZG93LnByb3RvdHlwZS5vblJlbW92ZWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMucm9vdC5hcHBseURlc2NlbmRhbnRzKGZ1bmN0aW9uICh0YWIpIHsgcmV0dXJuIHRhYi5yZW1vdmUoKTsgfSk7XG4gICAgfTtcbiAgICBXaW5kb3cucHJvdG90eXBlLmlzQ29ubmVjdGVkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5jb25uZWN0aW9uICE9PSB1bmRlZmluZWQ7XG4gICAgfTtcbiAgICByZXR1cm4gV2luZG93O1xufSgpKTtcbmV4cG9ydHMuZGVmYXVsdCA9IFdpbmRvdztcblxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vYXBwL3NjcmlwdHMvV2luZG93LnRzXG4vLyBtb2R1bGUgaWQgPSA0XG4vLyBtb2R1bGUgY2h1bmtzID0gMCAxIDIgMyA0IDUgNiIsIk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbnZhciBDb21tYW5kXzEgPSByZXF1aXJlKFwiLi9Db21tYW5kXCIpO1xudmFyIENvbm5lY3Rpb24gPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQ29ubmVjdGlvbigpIHtcbiAgICAgICAgLy8gUG9ydCBpcyBhY3RpdmUgYWZ0ZXIgT0sgbWVzc2FnZSBpcyByZWNlaXZlZCBmcm9tIFVzZXJTY3JpcHRcbiAgICAgICAgLy8gYW5kIG5vIGRpc2Nvbm5lY3QgZXZlbnQgaGF2ZSBiZWVuIHJlY2VpdmVkXG4gICAgICAgIHRoaXMuX2lzQWN0aXZlID0gZmFsc2U7XG4gICAgfVxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShDb25uZWN0aW9uLnByb3RvdHlwZSwgXCJwb3J0XCIsIHtcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fcG9ydDtcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShDb25uZWN0aW9uLnByb3RvdHlwZSwgXCJpc0Rpc2Nvbm5lY3RlZFwiLCB7XG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2lzRGlzY29ubmVjdGVkO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSk7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KENvbm5lY3Rpb24ucHJvdG90eXBlLCBcImlzQWN0aXZFXCIsIHtcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5faXNBY3RpdmU7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBDb25uZWN0aW9uLnByb3RvdHlwZS5hZGRMaXN0ZW5lcnMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMucG9ydC5vbkRpc2Nvbm5lY3QuYWRkTGlzdGVuZXIodGhpcy5vbkRpc2Nvbm5lY3QpO1xuICAgICAgICB0aGlzLnBvcnQub25NZXNzYWdlLmFkZExpc3RlbmVyKHRoaXMub25NZXNzYWdlKTtcbiAgICB9O1xuICAgIENvbm5lY3Rpb24ucHJvdG90eXBlLm9uTWVzc2FnZSA9IGZ1bmN0aW9uIChtZXNzYWdlLCBfcG9ydCkge1xuICAgICAgICAvLyBUT0RPOiBDb21tYW5kIHBhcnNpbmcgKyBkZWZpbml0aW9uc1xuICAgICAgICBpZiAobWVzc2FnZSA9PSAnT0snKSB7XG4gICAgICAgICAgICB0aGlzLl9pc0FjdGl2ZSA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVzc2FnZSA9PSAnQUNLJyB8fCBtZXNzYWdlID09ICdOQUNLJykge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ0V4dGVuc2lvbiByZXBseSA6ICcgKyBtZXNzYWdlKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZXNzYWdlLmNvbW1hbmQpIHtcbiAgICAgICAgICAgIENvbW1hbmRfMS5kZWZhdWx0Lm9uUmVjZWl2ZWQobWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIENvbm5lY3Rpb24ucHJvdG90eXBlLnNlbmRNZXNzYWdlID0gZnVuY3Rpb24gKG1lc3NhZ2UpIHtcbiAgICAgICAgdGhpcy5fcG9ydC5wb3N0TWVzc2FnZShtZXNzYWdlKTtcbiAgICAgICAgcmV0dXJuIGNocm9tZS5ydW50aW1lLmxhc3RFcnJvciA9PT0gdW5kZWZpbmVkO1xuICAgIH07XG4gICAgQ29ubmVjdGlvbi5wcm90b3R5cGUub25EaXNjb25uZWN0ID0gZnVuY3Rpb24gKHBvcnQpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1BvcnQgZGlzY29ubmVjdGVkJywgcG9ydCk7XG4gICAgICAgIHRoaXMuX2lzRGlzY29ubmVjdGVkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5faXNBY3RpdmUgPSBmYWxzZTtcbiAgICB9O1xuICAgIC8vIENvbm5lY3RJbmZvIGlzIHVzZWQgdG8gc2V0IHBvcnQgbmFtZVxuICAgIC8vIEN1cnJlbnQgbmFtZSBmb3JtYXQgaXM6IGB3aW5kb3ctPHdpbmRvdy5pZD5gXG4gICAgLy8gTmFtZSBpcyB1c2VkIGluIHVzZXIgc2NyaXB0IHRvIG1hdGNoIG1lc3NhZ2luZyBwb3J0cyBhbmQgYnJvd3Npbmcgd2luZG93c1xuICAgIENvbm5lY3Rpb24ucHJvdG90eXBlLmNvbm5lY3QgPSBmdW5jdGlvbiAoaW5mbykge1xuICAgICAgICAvLyBWaXZhbGRpJ3MgZXh0ZW5zaW9uIGlkLiBQcm9iYWJseSBzaG91bGRuJ3QgYmUgaGFyZGNvZGVkLlxuICAgICAgICB2YXIgZXh0SWQgPSAnbXBvZ25vYmJraWxkamtvZmFqaWZwZGZoY29rbGltbGknO1xuICAgICAgICB0aGlzLl9wb3J0ID0gY2hyb21lLnJ1bnRpbWUuY29ubmVjdChleHRJZCwgaW5mbyk7XG4gICAgICAgIGlmIChjaHJvbWUucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ29ubmVjdCBmYWlsZWQgdG8gYnJvd3Nlci5odG1sLidcbiAgICAgICAgICAgICAgICArICdJcyBicm93c2VyaG9vayBpbnN0YWxsZWQ/IGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcjogJ1xuICAgICAgICAgICAgICAgICsgY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuYWRkTGlzdGVuZXJzKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBDb25uZWN0aW9uO1xufSgpKTtcbmV4cG9ydHMuZGVmYXVsdCA9IENvbm5lY3Rpb247XG5cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL2FwcC9zY3JpcHRzL0Nvbm5lY3Rpb24udHNcbi8vIG1vZHVsZSBpZCA9IDVcbi8vIG1vZHVsZSBjaHVua3MgPSAwIDEgMiAzIDQgNSA2Il0sInNvdXJjZVJvb3QiOiIifQ==