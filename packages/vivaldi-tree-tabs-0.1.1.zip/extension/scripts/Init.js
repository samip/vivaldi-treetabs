/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 8);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
exports.tabContainer = exports.TabContainer = void 0;
var Tab_1 = __webpack_require__(1);
var TabContainer = /** @class */ (function () {
    function TabContainer() {
        this.tabs = new Map();
    }
    TabContainer.prototype.add = function (tab) {
        this.tabs.set(tab.id, tab);
    };
    TabContainer.prototype.get = function (id) {
        var tab = this.tabs.get(id);
        if (!tab) {
            throw new Error('Invalid access for tab id' + id);
        }
        return tab;
    };
    TabContainer.prototype.applyAll = function (callback) {
        this.tabs.forEach(function (tab) { return callback(tab); });
    };
    TabContainer.prototype.getFirst = function () {
        return this.tabs.values().next().value;
    };
    TabContainer.prototype.remove = function (tab) {
        if (this.tabs.get(tab.id)) {
            this.tabs.delete(tab.id);
        }
    };
    TabContainer.prototype.isEmpty = function () {
        return this.tabs.size === 0;
    };
    // Create tabs and their relationships
    TabContainer.prototype.initFromArray = function (tabs) {
        var _this = this;
        var parentQueue = new Map();
        tabs.forEach(function (tab) {
            var tabObj = new Tab_1.default(tab);
            // Parent already in container -> set parent normally
            if (tab.openerTabId) {
                var parent_1 = _this.get(tab.openerTabId);
                if (parent_1) {
                    tabObj.parentTo(parent_1);
                }
                // Parent not yet in container. Wait for it to be created
                else {
                    if (!parentQueue.has(tab.openerTabId)) {
                        parentQueue.set(tab.openerTabId, []);
                    }
                    // should be just parentQueue.get(tab.openerTabId).push(tabObj)
                    var siblingparentQueue = parentQueue.get(tab.openerTabId);
                    if (siblingparentQueue) {
                        siblingparentQueue.push(tabObj);
                    }
                }
            }
            // Top level tab -> parent to window's root tab
            else {
                var window_1 = tabObj.getWindow();
                tabObj.parentTo(window_1.root);
            }
            var queueForThis = parentQueue.get(tabObj.id);
            if (queueForThis) {
                // Children were created first -> parent them
                queueForThis.forEach(function (tab) {
                    tab.parentTo(tabObj);
                });
            }
            _this.add(tabObj);
        });
    };
    return TabContainer;
}());
exports.TabContainer = TabContainer;
// Contains references to all tabs from each window
exports.tabContainer = new TabContainer();


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
var TabContainer_1 = __webpack_require__(0);
var Command_1 = __webpack_require__(2);
var WindowContainer_1 = __webpack_require__(3);
var Tab = /** @class */ (function () {
    function Tab(chromeTab) {
        if (chromeTab) {
            if (chromeTab.id) {
                this.id = chromeTab.id;
            }
            else {
                // "Under some circumstances a tab may not be assigned an ID for example,
                // when querying foreign tabs using the sessions API"
                // should never happen here
                throw new Error('No tab id');
            }
            this.chromeTab = chromeTab;
            this.initialIndex = chromeTab.index;
        }
        else {
            this.isRoot = true;
            this.id = 0;
        }
        this.children = new TabContainer_1.TabContainer();
        this.closeChildrenButtonVisible = false;
    }
    // Call function on every child (but not children of children)
    Tab.prototype.applyChildren = function (callback) {
        this.children.applyAll(callback);
    };
    // Call function on every descendant (children, children of children
    Tab.prototype.applyDescendants = function (callback) {
        this.children.tabs.forEach(function (tab) {
            callback(tab);
            return tab.applyDescendants(callback);
        });
    };
    // Send tab specific command to Browserhook
    Tab.prototype.command = function (command, parameters) {
        if (parameters === void 0) { parameters = {}; }
        parameters['tabId'] = this.id;
        var cmd = new Command_1.default(command, parameters);
        cmd.send(this.getWindow());
    };
    // Traverse to root, return distance / depth / indentlevel  **/
    /* eg:
      -a: root
         - b: distance to root: 1
         - c: distance to root: 1
           - d: distance to root: 2
    */
    Tab.prototype.calculateDistanceToRoot = function () {
        var helper = function (tab, distance) {
            if (tab.parent) {
                if (tab.parent.isRoot) {
                    return helper(tab.parent, distance);
                }
                else {
                    return helper(tab.parent, ++distance);
                }
            }
            else {
                return distance;
            }
        };
        return helper(this, 0);
    };
    Tab.prototype.depth = function () {
        return this.calculateDistanceToRoot();
    };
    Tab.prototype.getWindow = function () {
        var windowId = this.chromeTab.windowId;
        return WindowContainer_1.windowContainer.get(windowId);
    };
    Tab.prototype.parentTo = function (parent) {
        // Add tab to new parent's child list
        parent.children.add(this);
        this.parent = parent;
        // Has children now -> show close children button
        // if (!parent.isRoot && !parent.closeChildrenButtonVisible) {
        if (!parent.isRoot) {
            parent.showCloseChildrenButton();
        }
        return this;
    };
    // Remove tab and parent it's children to own parent
    Tab.prototype.remove = function () {
        var _this = this;
        // Parent removed tab's children to own parent and redraw
        this.applyDescendants(function (child) {
            // Reparent direct children
            if (child.parent.id === _this.id) {
                child.parentTo(_this.parent);
            }
            // Re-render all descendants since their indentation has changed,      // while parent stayed the same.
            child.renderIndentation();
        });
        this.parent.children.remove(this); // remove from parent's children
        // The last child was removed -> hide close children button
        if (!this.parent.isRoot && this.parent.children.isEmpty()) {
            this.parent.hideCloseChildrenButton();
        }
    };
    Tab.prototype.removeChildren = function () {
        this.applyDescendants(function (child) {
            chrome.tabs.remove(child.id);
            if (chrome.runtime.lastError) {
                console.log('Error on removeChildren');
            }
        });
    };
    // Called on each tab after tab container reappear is redrawn.
    Tab.prototype.renderEverything = function () {
        if (!this.children.isEmpty()) {
            this.command('ShowCloseChildrenButton');
        }
        this.renderIndentation();
    };
    Tab.prototype.showCloseChildrenButton = function () {
        this.command('ShowCloseChildrenButton');
        this.closeChildrenButtonVisible = true;
    };
    Tab.prototype.hideCloseChildrenButton = function () {
        this.command('HideCloseChildrenButton');
        this.closeChildrenButtonVisible = false;
    };
    Tab.prototype.renderIndentation = function () {
        var depth = this.depth();
        this.command('IndentTab', { 'indentLevel': depth });
    };
    return Tab;
}());
exports.default = Tab;


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var TabContainer_1 = __webpack_require__(0);
var Command = /** @class */ (function () {
    function Command(command, parameters) {
        this.command = command;
        this.parameters = parameters;
        this.logEnabled = true;
    }
    // Send command to window via Chrome external messaging API
    Command.prototype.send = function (window) {
        var parameters = __assign(__assign({}, this.parameters), { command: this.command });
        if (!window.isConnected()) {
            window.connect();
            if (!window.isConnected()) {
                console.error('Cant connect to window', window);
                return;
            }
        }
        var success = window.connection.sendMessage(parameters);
        if (!success) {
            console.error('Command couldn\'t be sent');
        }
        if (this.logEnabled) {
            console.table(parameters);
            var logLine = success ? 'Sent to' : 'Failed to send';
            console.log(logLine, window);
        }
    };
    // Commands received from browserhook
    Command.onReceived = function (request) {
        console.log('Command received', request);
        switch (request.command) {
            case 'CloseChildren':
                var tab = TabContainer_1.tabContainer.get(request.tabId);
                tab.removeChildren();
                break;
            case 'RenderAllTabs':
                TabContainer_1.tabContainer.applyAll(function (tab) { return tab.renderEverything(); });
                break;
            default:
                console.error('Unknown command: ' + request.command);
                break;
        }
    };
    return Command;
}());
exports.default = Command;


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
exports.windowContainer = void 0;
var Window_1 = __webpack_require__(4);
var WindowContainer = /** @class */ (function () {
    function WindowContainer() {
        this.windows = new Map();
    }
    WindowContainer.prototype.add = function (window) {
        var key = window.id;
        this.windows.set(key, window);
    };
    WindowContainer.prototype.get = function (id) {
        var window = this.windows.get(id);
        if (!window) {
            throw new Error('WindowContainer: access to missing element. id:  ' + id);
        }
        return window;
    };
    WindowContainer.prototype.remove = function (window) {
        this.windows.delete(window.id);
    };
    WindowContainer.prototype.initFromArray = function (windows) {
        var _this = this;
        windows.forEach(function (chromeWindow) {
            // connect() doesn't work here due to a race-condition with messaging.
            // Try connecting when the message-bridge is actually needed; Command#send()
            var window = Window_1.default.init(chromeWindow);
            _this.add(window);
        });
    };
    return WindowContainer;
}());
exports.windowContainer = new WindowContainer();


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
var Tab_1 = __webpack_require__(1);
var Connection_1 = __webpack_require__(5);
var Window = /** @class */ (function () {
    function Window(id, chromeWindow) {
        this.id = id;
        this.chromeWindow = chromeWindow;
        this.root = new Tab_1.default();
    }
    Window.init = function (chromeWindow) {
        return new Window(chromeWindow.id, chromeWindow);
    };
    // Open messaging port between browser window and extension
    Window.prototype.connect = function () {
        var portName = "window-" + this.id;
        this.connection = new Connection_1.default();
        this.connection.connect({ name: portName });
    };
    Window.prototype.onRemoved = function () {
        this.root.applyDescendants(function (tab) { return tab.remove(); });
    };
    Window.prototype.isConnected = function () {
        return this.connection !== undefined;
    };
    return Window;
}());
exports.default = Window;


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
var Command_1 = __webpack_require__(2);
var Connection = /** @class */ (function () {
    function Connection() {
        // Port is active after OK message is received from UserScript
        // and no disconnect event have been received
        this._isActive = false;
    }
    Object.defineProperty(Connection.prototype, "port", {
        get: function () {
            return this._port;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Connection.prototype, "isDisconnected", {
        get: function () {
            return this._isDisconnected;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Connection.prototype, "isActivE", {
        get: function () {
            return this._isActive;
        },
        enumerable: false,
        configurable: true
    });
    Connection.prototype.addListeners = function () {
        this.port.onDisconnect.addListener(this.onDisconnect);
        this.port.onMessage.addListener(this.onMessage);
    };
    Connection.prototype.onMessage = function (message, _port) {
        // TODO: Command parsing + definitions
        if (message == 'OK') {
            this._isActive = true;
        }
        else if (message == 'ACK' || message == 'NACK') {
            console.log('Extension reply : ' + message);
        }
        else if (message.command) {
            Command_1.default.onReceived(message);
        }
    };
    Connection.prototype.sendMessage = function (message) {
        this._port.postMessage(message);
        return chrome.runtime.lastError === undefined;
    };
    Connection.prototype.onDisconnect = function (port) {
        console.log('Port disconnected', port);
        this._isDisconnected = true;
        this._isActive = false;
    };
    // ConnectInfo is used to set port name
    // Current name format is: `window-<window.id>`
    // Name is used in user script to match messaging ports and browsing windows
    Connection.prototype.connect = function (info) {
        // Vivaldi's extension id. Probably shouldn't be hardcoded.
        var extId = 'mpognobbkildjkofajifpdfhcoklimli';
        this._port = chrome.runtime.connect(extId, info);
        if (chrome.runtime.lastError) {
            throw new Error('Connect failed to browser.html.'
                + 'Is browserhook installed? chrome.runtime.lastError: '
                + chrome.runtime.lastError);
        }
        else {
            this.addListeners();
        }
    };
    return Connection;
}());
exports.default = Connection;


/***/ }),
/* 6 */,
/* 7 */,
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(9);


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", { value: true });
__webpack_require__(10); // Remove this before building
var Tab_1 = __webpack_require__(1);
var TabContainer_1 = __webpack_require__(0);
var WindowContainer_1 = __webpack_require__(3);
var Window_1 = __webpack_require__(4);
var ChromeCallbacks = /** @class */ (function () {
    function ChromeCallbacks() {
    }
    ChromeCallbacks.onTabCreated = function (chromeTab) {
        var tab = new Tab_1.default(chromeTab);
        TabContainer_1.tabContainer.add(tab);
        // child tab created -> set parent and indent.
        if (chromeTab.openerTabId) {
            var parentTab = TabContainer_1.tabContainer.get(chromeTab.openerTabId);
            tab.parentTo(parentTab);
            tab.renderIndentation();
        }
        // top level tab -> parent to window's root node
        else {
            var root = tab.getWindow().root;
            tab.parentTo(root);
        }
    };
    ChromeCallbacks.onTabMoved = function (tabId, info) {
        var tab = TabContainer_1.tabContainer.get(tabId);
        var root = tab.getWindow().root;
        // whether this was final move event made by Vivaldi
        var correctEvent = tab.initialIndex === info.fromIndex;
        // top level tab needs to repositioned outside existing branches
        if (tab.parent.isRoot && correctEvent) {
            var searchBelow_1 = info.toIndex; // search for spot below created tab
            var processed_1 = 0;
            var minIndex_1;
            // This lags sometimes.
            // TODO: keep track of tab order to avoid api call?
            // TODO: Figure out what this does and rewrite
            root.children.tabs.forEach(function (item) {
                // get current index
                chrome.tabs.get(item.id, function (tab) {
                    var prev = --tab.index;
                    if (prev > searchBelow_1) {
                        if (!minIndex_1 || prev <= minIndex_1) {
                            minIndex_1 = prev;
                        }
                    }
                    else if (prev === searchBelow_1) {
                        minIndex_1 = prev;
                        return;
                    }
                    processed_1++;
                    if (processed_1 === root.children.tabs.size) {
                        minIndex_1 = (minIndex_1) ? minIndex_1 : 999;
                        chrome.tabs.move([item.id], { index: minIndex_1 });
                    }
                });
            });
        }
    };
    ChromeCallbacks.onTabRemoved = function (tabId) {
        var tab = TabContainer_1.tabContainer.get(tabId);
        if (!tab)
            return;
        tab.remove();
        TabContainer_1.tabContainer.remove(tab);
    };
    // Tab moved to new window -> reparent to new Window's root
    ChromeCallbacks.onTabAttached = function (tabId, info) {
        var tab = TabContainer_1.tabContainer.get(tabId);
        if (!tab)
            return;
        var newWindow = WindowContainer_1.windowContainer.get(info.newWindowId);
        tab.parentTo(newWindow.root);
        tab.renderIndentation();
    };
    // move children to new window with their parent?
    ChromeCallbacks.onTabDetached = function (tabId, _info) {
        var tab = TabContainer_1.tabContainer.get(tabId);
        if (!tab)
            return;
        tab.children.tabs.forEach(function (child) {
            child.parentTo(tab.parent);
            child.renderIndentation();
        });
    };
    // https://developer.chrome.com/docs/extensions/reference/tabs/#event-onUpdated
    ChromeCallbacks.onTabUpdated = function (tabId, info) {
        var tab = TabContainer_1.tabContainer.get(tabId);
        if (info.pinned && tab) {
            // Tab pinned -> parent children to tab's parent
            tab.children.applyAll(function (child) {
                child.parentTo(tab.parent);
                child.renderIndentation();
            });
            tab.parentTo(tab.getWindow().root);
            // TODO: fix problems when an intended tab is pinned
        }
    };
    ChromeCallbacks.onWindowCreated = function (chromeWindow) {
        var window = Window_1.default.init(chromeWindow);
        // Connect only when needed to avoid race conditions
        // (window is not really to process messaging immediately)
        // window.connect()
        WindowContainer_1.windowContainer.add(window);
    };
    ChromeCallbacks.onWindowRemoved = function (windowId) {
        var window = WindowContainer_1.windowContainer.get(windowId);
        WindowContainer_1.windowContainer.remove(window);
    };
    return ChromeCallbacks;
}());
// Initialize tab and window containers
chrome.windows.getAll(WindowContainer_1.windowContainer.initFromArray.bind(WindowContainer_1.windowContainer));
chrome.tabs.query({}, TabContainer_1.tabContainer.initFromArray.bind(TabContainer_1.tabContainer));
chrome.tabs.onCreated.addListener(ChromeCallbacks.onTabCreated);
chrome.tabs.onMoved.addListener(ChromeCallbacks.onTabMoved);
chrome.tabs.onRemoved.addListener(ChromeCallbacks.onTabRemoved);
chrome.tabs.onAttached.addListener(ChromeCallbacks.onTabAttached);
chrome.tabs.onDetached.addListener(ChromeCallbacks.onTabDetached);
chrome.tabs.onUpdated.addListener(ChromeCallbacks.onTabUpdated);
chrome.windows.onCreated.addListener(ChromeCallbacks.onWindowCreated);
chrome.windows.onRemoved.addListener(ChromeCallbacks.onWindowRemoved);


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _chromereload = __webpack_require__(11);

var _chromereload2 = _interopRequireDefault(_chromereload);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

if (true) {
  new _chromereload2.default();
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9kZXZvbmx5LmpzIl0sIm5hbWVzIjpbInByb2Nlc3MiLCJlbnYiLCJOT0RFX0VOViJdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7O0FBRUEsSUFBSUEsUUFBUUMsR0FBUixDQUFZQyxRQUFaLEtBQXlCLGFBQTdCLEVBQTRDO0FBQzFDO0FBQ0QiLCJmaWxlIjoiZGV2b25seS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBDaHJvbWVSZWxvYWQgZnJvbSAnLi9jaHJvbWVyZWxvYWQuanMnO1xuXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgbmV3IENocm9tZVJlbG9hZCgpO1xufVxuIl19

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var ChromeReload = function () {
  function ChromeReload() {
    var args = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

    _classCallCheck(this, ChromeReload);

    var _args$host = args.host;
    var host = _args$host === undefined ? 'localhost' : _args$host;
    var _args$port = args.port;
    var port = _args$port === undefined ? 35729 : _args$port;
    var _args$reconnectTime = args.reconnectTime;
    var reconnectTime = _args$reconnectTime === undefined ? 3000 : _args$reconnectTime;
    var _args$debug = args.debug;
    var debug = _args$debug === undefined ? true : _args$debug;


    this.host = host;
    this.port = port;
    this.reconnectTime = reconnectTime;
    this.debug = debug;

    this.connect = this.connect.bind(this);
    this.onerror = this.onerror.bind(this);
    this.onopen = this.onopen.bind(this);
    this._onmessage = this._onmessage.bind(this);
    this.onmessage = this.onmessage.bind(this);
    this.onclose = this.onclose.bind(this);

    this.state = {
      connected: false,
      connectionLost: false,
      reloading: false
    };

    this.connect();
  }

  _createClass(ChromeReload, [{
    key: 'connect',
    value: function connect() {
      this.connection = new WebSocket('ws://' + this.host + ':' + this.port + '/livereload');
      this.connection.onopen = this.onopen;
      this.connection.onmessage = this._onmessage;
      this.connection.onerror = this.onerror;
      this.connection.onclose = this.onclose;
    }
  }, {
    key: 'onopen',
    value: function onopen() {
      this.log('Enabled');
      this.state.connected = true;
    }
  }, {
    key: 'onerror',
    value: function onerror(error) {
      this.log('Connection error');
      this.state.connected = false;
      this.state.connectionLost = true;
    }
  }, {
    key: '_onmessage',
    value: function _onmessage(event) {
      if (event.data) {
        this.onmessage(JSON.parse(event.data));
      }
    }
  }, {
    key: 'onmessage',
    value: function onmessage(_ref) {
      var command = _ref.command;
      var path = _ref.path;

      var connectionLost = this.state.connectionLost;
      var scriptreload = /\.js$/.test(path);

      if (command === 'reload') {

        if (connectionLost && !scriptreload) {
          this.log('Waiting for scripts to be ready.');
          return;
        }

        this.state.connectionLost = false;
        this.reload();
      }
    }
  }, {
    key: 'onclose',
    value: function onclose() {
      this.log('Connection lost. Reconnecting in %ss', this.reconnectTime);
      setTimeout(this.connect, this.reconnectTime);
    }
  }, {
    key: 'reload',
    value: function reload() {
      if (this.state.reloading) {
        return;
      }
      this.state.reloading = true;
      this.log('Reloading ...');
      if (chrome.runtime && chrome.runtime.reload) {
        // If we are on a background page
        // we should reload the entire runtime
        chrome.runtime.reload();
      } else {
        // Sometimes we are on a different context
        // for example a contentscript
        // therefore we need to reload via
        // window.location
        window.location.reload();
      }
    }
  }, {
    key: 'log',
    value: function log(message) {
      if (this.debug) {
        var _console;

        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          args[_key - 1] = arguments[_key];
        }

        (_console = console).log.apply(_console, ['%cChromeReload: ' + message, 'color: gray;'].concat(args));
      }
    }
  }]);

  return ChromeReload;
}();

exports.default = ChromeReload;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9jaHJvbWVyZWxvYWQuanMiXSwibmFtZXMiOlsiQ2hyb21lUmVsb2FkIiwiYXJncyIsImhvc3QiLCJwb3J0IiwicmVjb25uZWN0VGltZSIsImRlYnVnIiwiY29ubmVjdCIsImJpbmQiLCJvbmVycm9yIiwib25vcGVuIiwiX29ubWVzc2FnZSIsIm9ubWVzc2FnZSIsIm9uY2xvc2UiLCJzdGF0ZSIsImNvbm5lY3RlZCIsImNvbm5lY3Rpb25Mb3N0IiwicmVsb2FkaW5nIiwiY29ubmVjdGlvbiIsIldlYlNvY2tldCIsImxvZyIsImVycm9yIiwiZXZlbnQiLCJkYXRhIiwiSlNPTiIsInBhcnNlIiwiY29tbWFuZCIsInBhdGgiLCJzY3JpcHRyZWxvYWQiLCJ0ZXN0IiwicmVsb2FkIiwic2V0VGltZW91dCIsImNocm9tZSIsInJ1bnRpbWUiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsIm1lc3NhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7SUFBTUEsWTtBQUNKLDBCQUF1QjtBQUFBLFFBQVhDLElBQVcseURBQUosRUFBSTs7QUFBQTs7QUFBQSxxQkFNakJBLElBTmlCLENBRW5CQyxJQUZtQjtBQUFBLFFBRW5CQSxJQUZtQiw4QkFFWixXQUZZO0FBQUEscUJBTWpCRCxJQU5pQixDQUduQkUsSUFIbUI7QUFBQSxRQUduQkEsSUFIbUIsOEJBR1osS0FIWTtBQUFBLDhCQU1qQkYsSUFOaUIsQ0FJbkJHLGFBSm1CO0FBQUEsUUFJbkJBLGFBSm1CLHVDQUlILElBSkc7QUFBQSxzQkFNakJILElBTmlCLENBS25CSSxLQUxtQjtBQUFBLFFBS25CQSxLQUxtQiwrQkFLWCxJQUxXOzs7QUFRckIsU0FBS0gsSUFBTCxHQUFZQSxJQUFaO0FBQ0EsU0FBS0MsSUFBTCxHQUFZQSxJQUFaO0FBQ0EsU0FBS0MsYUFBTCxHQUFxQkEsYUFBckI7QUFDQSxTQUFLQyxLQUFMLEdBQWFBLEtBQWI7O0FBRUEsU0FBS0MsT0FBTCxHQUFlLEtBQUtBLE9BQUwsQ0FBYUMsSUFBYixDQUFrQixJQUFsQixDQUFmO0FBQ0EsU0FBS0MsT0FBTCxHQUFlLEtBQUtBLE9BQUwsQ0FBYUQsSUFBYixDQUFrQixJQUFsQixDQUFmO0FBQ0EsU0FBS0UsTUFBTCxHQUFjLEtBQUtBLE1BQUwsQ0FBWUYsSUFBWixDQUFpQixJQUFqQixDQUFkO0FBQ0EsU0FBS0csVUFBTCxHQUFrQixLQUFLQSxVQUFMLENBQWdCSCxJQUFoQixDQUFxQixJQUFyQixDQUFsQjtBQUNBLFNBQUtJLFNBQUwsR0FBaUIsS0FBS0EsU0FBTCxDQUFlSixJQUFmLENBQW9CLElBQXBCLENBQWpCO0FBQ0EsU0FBS0ssT0FBTCxHQUFlLEtBQUtBLE9BQUwsQ0FBYUwsSUFBYixDQUFrQixJQUFsQixDQUFmOztBQUVBLFNBQUtNLEtBQUwsR0FBYTtBQUNYQyxpQkFBVyxLQURBO0FBRVhDLHNCQUFnQixLQUZMO0FBR1hDLGlCQUFXO0FBSEEsS0FBYjs7QUFNQSxTQUFLVixPQUFMO0FBQ0Q7Ozs7OEJBRVM7QUFDUixXQUFLVyxVQUFMLEdBQWtCLElBQUlDLFNBQUosV0FBc0IsS0FBS2hCLElBQTNCLFNBQW1DLEtBQUtDLElBQXhDLGlCQUFsQjtBQUNBLFdBQUtjLFVBQUwsQ0FBZ0JSLE1BQWhCLEdBQXlCLEtBQUtBLE1BQTlCO0FBQ0EsV0FBS1EsVUFBTCxDQUFnQk4sU0FBaEIsR0FBNEIsS0FBS0QsVUFBakM7QUFDQSxXQUFLTyxVQUFMLENBQWdCVCxPQUFoQixHQUEwQixLQUFLQSxPQUEvQjtBQUNBLFdBQUtTLFVBQUwsQ0FBZ0JMLE9BQWhCLEdBQTBCLEtBQUtBLE9BQS9CO0FBQ0Q7Ozs2QkFFUTtBQUNQLFdBQUtPLEdBQUwsQ0FBUyxTQUFUO0FBQ0EsV0FBS04sS0FBTCxDQUFXQyxTQUFYLEdBQXVCLElBQXZCO0FBQ0Q7Ozs0QkFFT00sSyxFQUFPO0FBQ2IsV0FBS0QsR0FBTCxDQUFTLGtCQUFUO0FBQ0EsV0FBS04sS0FBTCxDQUFXQyxTQUFYLEdBQXVCLEtBQXZCO0FBQ0EsV0FBS0QsS0FBTCxDQUFXRSxjQUFYLEdBQTRCLElBQTVCO0FBQ0Q7OzsrQkFFVU0sSyxFQUFPO0FBQ2hCLFVBQUlBLE1BQU1DLElBQVYsRUFBZ0I7QUFDZCxhQUFLWCxTQUFMLENBQ0VZLEtBQUtDLEtBQUwsQ0FBV0gsTUFBTUMsSUFBakIsQ0FERjtBQUdEO0FBQ0Y7OztvQ0FLRTtBQUFBLFVBRkRHLE9BRUMsUUFGREEsT0FFQztBQUFBLFVBRERDLElBQ0MsUUFEREEsSUFDQzs7QUFDRCxVQUFNWCxpQkFBaUIsS0FBS0YsS0FBTCxDQUFXRSxjQUFsQztBQUNBLFVBQU1ZLGVBQWUsUUFBUUMsSUFBUixDQUFhRixJQUFiLENBQXJCOztBQUVBLFVBQUlELFlBQVksUUFBaEIsRUFBMEI7O0FBRXhCLFlBQUlWLGtCQUFrQixDQUFDWSxZQUF2QixFQUFxQztBQUNuQyxlQUFLUixHQUFMLENBQVMsa0NBQVQ7QUFDQTtBQUNEOztBQUVELGFBQUtOLEtBQUwsQ0FBV0UsY0FBWCxHQUE0QixLQUE1QjtBQUNBLGFBQUtjLE1BQUw7QUFDRDtBQUNGOzs7OEJBRVM7QUFDUixXQUFLVixHQUFMLENBQVMsc0NBQVQsRUFBaUQsS0FBS2YsYUFBdEQ7QUFDQTBCLGlCQUFXLEtBQUt4QixPQUFoQixFQUF5QixLQUFLRixhQUE5QjtBQUNEOzs7NkJBRVE7QUFDUCxVQUFJLEtBQUtTLEtBQUwsQ0FBV0csU0FBZixFQUEwQjtBQUN4QjtBQUNEO0FBQ0QsV0FBS0gsS0FBTCxDQUFXRyxTQUFYLEdBQXVCLElBQXZCO0FBQ0EsV0FBS0csR0FBTCxDQUFTLGVBQVQ7QUFDQSxVQUFJWSxPQUFPQyxPQUFQLElBQWtCRCxPQUFPQyxPQUFQLENBQWVILE1BQXJDLEVBQTZDO0FBQzNDO0FBQ0E7QUFDQUUsZUFBT0MsT0FBUCxDQUFlSCxNQUFmO0FBQ0QsT0FKRCxNQUlPO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQUksZUFBT0MsUUFBUCxDQUFnQkwsTUFBaEI7QUFDRDtBQUNGOzs7d0JBRUdNLE8sRUFBa0I7QUFDcEIsVUFBRyxLQUFLOUIsS0FBUixFQUFlO0FBQUE7O0FBQUEsMENBRERKLElBQ0M7QUFEREEsY0FDQztBQUFBOztBQUNiLDZCQUFRa0IsR0FBUix1Q0FBK0JnQixPQUEvQixFQUEwQyxjQUExQyxTQUE2RGxDLElBQTdEO0FBQ0Q7QUFDRjs7Ozs7O2tCQUdZRCxZIiwiZmlsZSI6ImNocm9tZXJlbG9hZC5qcyIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIENocm9tZVJlbG9hZCB7XG4gIGNvbnN0cnVjdG9yKGFyZ3MgPSB7fSkge1xuICAgIGNvbnN0IHtcbiAgICAgIGhvc3QgPSAnbG9jYWxob3N0JyxcbiAgICAgIHBvcnQgPSAzNTcyOSxcbiAgICAgIHJlY29ubmVjdFRpbWUgPSAzMDAwLFxuICAgICAgZGVidWcgPSB0cnVlXG4gICAgfSA9IGFyZ3M7XG5cbiAgICB0aGlzLmhvc3QgPSBob3N0O1xuICAgIHRoaXMucG9ydCA9IHBvcnQ7XG4gICAgdGhpcy5yZWNvbm5lY3RUaW1lID0gcmVjb25uZWN0VGltZTtcbiAgICB0aGlzLmRlYnVnID0gZGVidWc7XG5cbiAgICB0aGlzLmNvbm5lY3QgPSB0aGlzLmNvbm5lY3QuYmluZCh0aGlzKTtcbiAgICB0aGlzLm9uZXJyb3IgPSB0aGlzLm9uZXJyb3IuYmluZCh0aGlzKTtcbiAgICB0aGlzLm9ub3BlbiA9IHRoaXMub25vcGVuLmJpbmQodGhpcyk7XG4gICAgdGhpcy5fb25tZXNzYWdlID0gdGhpcy5fb25tZXNzYWdlLmJpbmQodGhpcyk7XG4gICAgdGhpcy5vbm1lc3NhZ2UgPSB0aGlzLm9ubWVzc2FnZS5iaW5kKHRoaXMpO1xuICAgIHRoaXMub25jbG9zZSA9IHRoaXMub25jbG9zZS5iaW5kKHRoaXMpO1xuXG4gICAgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIGNvbm5lY3RlZDogZmFsc2UsXG4gICAgICBjb25uZWN0aW9uTG9zdDogZmFsc2UsXG4gICAgICByZWxvYWRpbmc6IGZhbHNlXG4gICAgfTtcblxuICAgIHRoaXMuY29ubmVjdCgpO1xuICB9XG5cbiAgY29ubmVjdCgpIHtcbiAgICB0aGlzLmNvbm5lY3Rpb24gPSBuZXcgV2ViU29ja2V0KGB3czovLyR7dGhpcy5ob3N0fToke3RoaXMucG9ydH0vbGl2ZXJlbG9hZGApO1xuICAgIHRoaXMuY29ubmVjdGlvbi5vbm9wZW4gPSB0aGlzLm9ub3BlbjtcbiAgICB0aGlzLmNvbm5lY3Rpb24ub25tZXNzYWdlID0gdGhpcy5fb25tZXNzYWdlO1xuICAgIHRoaXMuY29ubmVjdGlvbi5vbmVycm9yID0gdGhpcy5vbmVycm9yO1xuICAgIHRoaXMuY29ubmVjdGlvbi5vbmNsb3NlID0gdGhpcy5vbmNsb3NlO1xuICB9XG5cbiAgb25vcGVuKCkge1xuICAgIHRoaXMubG9nKCdFbmFibGVkJyk7XG4gICAgdGhpcy5zdGF0ZS5jb25uZWN0ZWQgPSB0cnVlO1xuICB9XG5cbiAgb25lcnJvcihlcnJvcikge1xuICAgIHRoaXMubG9nKCdDb25uZWN0aW9uIGVycm9yJyk7XG4gICAgdGhpcy5zdGF0ZS5jb25uZWN0ZWQgPSBmYWxzZTtcbiAgICB0aGlzLnN0YXRlLmNvbm5lY3Rpb25Mb3N0ID0gdHJ1ZTtcbiAgfVxuXG4gIF9vbm1lc3NhZ2UoZXZlbnQpIHtcbiAgICBpZiAoZXZlbnQuZGF0YSkge1xuICAgICAgdGhpcy5vbm1lc3NhZ2UoXG4gICAgICAgIEpTT04ucGFyc2UoZXZlbnQuZGF0YSlcbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgb25tZXNzYWdlKHtcbiAgICBjb21tYW5kLFxuICAgIHBhdGhcbiAgfSkge1xuICAgIGNvbnN0IGNvbm5lY3Rpb25Mb3N0ID0gdGhpcy5zdGF0ZS5jb25uZWN0aW9uTG9zdDtcbiAgICBjb25zdCBzY3JpcHRyZWxvYWQgPSAvXFwuanMkLy50ZXN0KHBhdGgpO1xuXG4gICAgaWYgKGNvbW1hbmQgPT09ICdyZWxvYWQnKSB7XG5cbiAgICAgIGlmIChjb25uZWN0aW9uTG9zdCAmJiAhc2NyaXB0cmVsb2FkKSB7XG4gICAgICAgIHRoaXMubG9nKCdXYWl0aW5nIGZvciBzY3JpcHRzIHRvIGJlIHJlYWR5LicpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIHRoaXMuc3RhdGUuY29ubmVjdGlvbkxvc3QgPSBmYWxzZTtcbiAgICAgIHRoaXMucmVsb2FkKCk7XG4gICAgfVxuICB9XG5cbiAgb25jbG9zZSgpIHtcbiAgICB0aGlzLmxvZygnQ29ubmVjdGlvbiBsb3N0LiBSZWNvbm5lY3RpbmcgaW4gJXNzJywgdGhpcy5yZWNvbm5lY3RUaW1lKTtcbiAgICBzZXRUaW1lb3V0KHRoaXMuY29ubmVjdCwgdGhpcy5yZWNvbm5lY3RUaW1lKTtcbiAgfVxuXG4gIHJlbG9hZCgpIHtcbiAgICBpZiAodGhpcy5zdGF0ZS5yZWxvYWRpbmcpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5zdGF0ZS5yZWxvYWRpbmcgPSB0cnVlO1xuICAgIHRoaXMubG9nKCdSZWxvYWRpbmcgLi4uJyk7XG4gICAgaWYgKGNocm9tZS5ydW50aW1lICYmIGNocm9tZS5ydW50aW1lLnJlbG9hZCkge1xuICAgICAgLy8gSWYgd2UgYXJlIG9uIGEgYmFja2dyb3VuZCBwYWdlXG4gICAgICAvLyB3ZSBzaG91bGQgcmVsb2FkIHRoZSBlbnRpcmUgcnVudGltZVxuICAgICAgY2hyb21lLnJ1bnRpbWUucmVsb2FkKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFNvbWV0aW1lcyB3ZSBhcmUgb24gYSBkaWZmZXJlbnQgY29udGV4dFxuICAgICAgLy8gZm9yIGV4YW1wbGUgYSBjb250ZW50c2NyaXB0XG4gICAgICAvLyB0aGVyZWZvcmUgd2UgbmVlZCB0byByZWxvYWQgdmlhXG4gICAgICAvLyB3aW5kb3cubG9jYXRpb25cbiAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgICB9XG4gIH1cblxuICBsb2cobWVzc2FnZSwgLi4uYXJncykge1xuICAgIGlmKHRoaXMuZGVidWcpIHtcbiAgICAgIGNvbnNvbGUubG9nKGAlY0Nocm9tZVJlbG9hZDogJHttZXNzYWdlfWAsICdjb2xvcjogZ3JheTsnLCAuLi5hcmdzKTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgQ2hyb21lUmVsb2FkO1xuIl19

/***/ })
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgMWQ3NWNhYWYzZDZmNWFhZDQ3M2MiLCJ3ZWJwYWNrOi8vLy4vYXBwL3NjcmlwdHMvVGFiQ29udGFpbmVyLnRzIiwid2VicGFjazovLy8uL2FwcC9zY3JpcHRzL1RhYi50cyIsIndlYnBhY2s6Ly8vLi9hcHAvc2NyaXB0cy9Db21tYW5kLnRzIiwid2VicGFjazovLy8uL2FwcC9zY3JpcHRzL1dpbmRvd0NvbnRhaW5lci50cyIsIndlYnBhY2s6Ly8vLi9hcHAvc2NyaXB0cy9XaW5kb3cudHMiLCJ3ZWJwYWNrOi8vLy4vYXBwL3NjcmlwdHMvQ29ubmVjdGlvbi50cyIsIndlYnBhY2s6Ly8vLi9hcHAvc2NyaXB0cy9Jbml0LnRzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9jaHJvbWVyZWxvYWQvZGV2b25seS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvY2hyb21lcmVsb2FkL2Nocm9tZXJlbG9hZC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLEtBQUs7UUFDTDtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOztRQUVBO1FBQ0E7Ozs7Ozs7QUM3REEsOENBQThDLGNBQWM7QUFDNUQ7QUFDQSxZQUFZLG1CQUFPLENBQUMsQ0FBTztBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQ0FBMEMsc0JBQXNCLEVBQUU7QUFDbEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTs7Ozs7OztBQzFFQSw4Q0FBOEMsY0FBYztBQUM1RCxxQkFBcUIsbUJBQU8sQ0FBQyxDQUFnQjtBQUM3QyxnQkFBZ0IsbUJBQU8sQ0FBQyxDQUFXO0FBQ25DLHdCQUF3QixtQkFBTyxDQUFDLENBQW1CO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxpQkFBaUI7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCwwQ0FBMEM7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsdUJBQXVCO0FBQzFEO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7Ozs7Ozs7QUNwSUE7QUFDQTtBQUNBLGdEQUFnRCxPQUFPO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBOEMsY0FBYztBQUM1RCxxQkFBcUIsbUJBQU8sQ0FBQyxDQUFnQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDLHFCQUFxQix3QkFBd0I7QUFDMUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFFQUFxRSwrQkFBK0IsRUFBRTtBQUN0RztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDs7Ozs7OztBQ3pEQSw4Q0FBOEMsY0FBYztBQUM1RDtBQUNBLGVBQWUsbUJBQU8sQ0FBQyxDQUFVO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUVBQXlFO0FBQ3pFO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLENBQUM7QUFDRDs7Ozs7OztBQ2hDQSw4Q0FBOEMsY0FBYztBQUM1RCxZQUFZLG1CQUFPLENBQUMsQ0FBTztBQUMzQixtQkFBbUIsbUJBQU8sQ0FBQyxDQUFjO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDLGlCQUFpQjtBQUNsRDtBQUNBO0FBQ0EsbURBQW1ELHFCQUFxQixFQUFFO0FBQzFFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7Ozs7Ozs7QUMxQkEsOENBQThDLGNBQWM7QUFDNUQsZ0JBQWdCLG1CQUFPLENBQUMsQ0FBVztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4RUEsOENBQThDLGNBQWM7QUFDNUQsbUJBQU8sQ0FBQyxFQUFzQixFQUFFO0FBQ2hDLFlBQVksbUJBQU8sQ0FBQyxDQUFPO0FBQzNCLHFCQUFxQixtQkFBTyxDQUFDLENBQWdCO0FBQzdDLHdCQUF3QixtQkFBTyxDQUFDLENBQW1CO0FBQ25ELGVBQWUsbUJBQU8sQ0FBQyxDQUFVO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCxvQkFBb0I7QUFDekU7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQSxvQkFBb0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUN6SGE7O0FBRWIsb0JBQW9CLG1CQUFPLENBQUMsRUFBbUI7O0FBRS9DOztBQUVBLHNDQUFzQyx1Q0FBdUMsZ0JBQWdCOztBQUU3RixJQUFJLElBQXNDO0FBQzFDO0FBQ0E7QUFDQSwyQ0FBMkMsK2I7Ozs7Ozs7QUNYOUI7O0FBRWI7QUFDQTtBQUNBLENBQUM7O0FBRUQsZ0NBQWdDLDJDQUEyQyxnQkFBZ0Isa0JBQWtCLE9BQU8sMkJBQTJCLHdEQUF3RCxnQ0FBZ0MsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUseURBQXlELHFFQUFxRSw2REFBNkQsb0JBQW9CLEdBQUcsRUFBRTs7QUFFampCLGlEQUFpRCwwQ0FBMEMsMERBQTBELEVBQUU7O0FBRXZKO0FBQ0E7QUFDQSx1RUFBdUU7O0FBRXZFOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTs7QUFFQSwwRkFBMEYsYUFBYTtBQUN2RztBQUNBOztBQUVBLDZGQUE2RjtBQUM3RjtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBLENBQUM7O0FBRUQ7QUFDQSwyQ0FBMkMsMmpPIiwiZmlsZSI6IkluaXQuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHtcbiBcdFx0XHRcdGNvbmZpZ3VyYWJsZTogZmFsc2UsXG4gXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuIFx0XHRcdFx0Z2V0OiBnZXR0ZXJcbiBcdFx0XHR9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSA4KTtcblxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyB3ZWJwYWNrL2Jvb3RzdHJhcCAxZDc1Y2FhZjNkNmY1YWFkNDczYyIsIk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMudGFiQ29udGFpbmVyID0gZXhwb3J0cy5UYWJDb250YWluZXIgPSB2b2lkIDA7XG52YXIgVGFiXzEgPSByZXF1aXJlKFwiLi9UYWJcIik7XG52YXIgVGFiQ29udGFpbmVyID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFRhYkNvbnRhaW5lcigpIHtcbiAgICAgICAgdGhpcy50YWJzID0gbmV3IE1hcCgpO1xuICAgIH1cbiAgICBUYWJDb250YWluZXIucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uICh0YWIpIHtcbiAgICAgICAgdGhpcy50YWJzLnNldCh0YWIuaWQsIHRhYik7XG4gICAgfTtcbiAgICBUYWJDb250YWluZXIucHJvdG90eXBlLmdldCA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICB2YXIgdGFiID0gdGhpcy50YWJzLmdldChpZCk7XG4gICAgICAgIGlmICghdGFiKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgYWNjZXNzIGZvciB0YWIgaWQnICsgaWQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0YWI7XG4gICAgfTtcbiAgICBUYWJDb250YWluZXIucHJvdG90eXBlLmFwcGx5QWxsID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gICAgICAgIHRoaXMudGFicy5mb3JFYWNoKGZ1bmN0aW9uICh0YWIpIHsgcmV0dXJuIGNhbGxiYWNrKHRhYik7IH0pO1xuICAgIH07XG4gICAgVGFiQ29udGFpbmVyLnByb3RvdHlwZS5nZXRGaXJzdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudGFicy52YWx1ZXMoKS5uZXh0KCkudmFsdWU7XG4gICAgfTtcbiAgICBUYWJDb250YWluZXIucHJvdG90eXBlLnJlbW92ZSA9IGZ1bmN0aW9uICh0YWIpIHtcbiAgICAgICAgaWYgKHRoaXMudGFicy5nZXQodGFiLmlkKSkge1xuICAgICAgICAgICAgdGhpcy50YWJzLmRlbGV0ZSh0YWIuaWQpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBUYWJDb250YWluZXIucHJvdG90eXBlLmlzRW1wdHkgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnRhYnMuc2l6ZSA9PT0gMDtcbiAgICB9O1xuICAgIC8vIENyZWF0ZSB0YWJzIGFuZCB0aGVpciByZWxhdGlvbnNoaXBzXG4gICAgVGFiQ29udGFpbmVyLnByb3RvdHlwZS5pbml0RnJvbUFycmF5ID0gZnVuY3Rpb24gKHRhYnMpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgdmFyIHBhcmVudFF1ZXVlID0gbmV3IE1hcCgpO1xuICAgICAgICB0YWJzLmZvckVhY2goZnVuY3Rpb24gKHRhYikge1xuICAgICAgICAgICAgdmFyIHRhYk9iaiA9IG5ldyBUYWJfMS5kZWZhdWx0KHRhYik7XG4gICAgICAgICAgICAvLyBQYXJlbnQgYWxyZWFkeSBpbiBjb250YWluZXIgLT4gc2V0IHBhcmVudCBub3JtYWxseVxuICAgICAgICAgICAgaWYgKHRhYi5vcGVuZXJUYWJJZCkge1xuICAgICAgICAgICAgICAgIHZhciBwYXJlbnRfMSA9IF90aGlzLmdldCh0YWIub3BlbmVyVGFiSWQpO1xuICAgICAgICAgICAgICAgIGlmIChwYXJlbnRfMSkge1xuICAgICAgICAgICAgICAgICAgICB0YWJPYmoucGFyZW50VG8ocGFyZW50XzEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBQYXJlbnQgbm90IHlldCBpbiBjb250YWluZXIuIFdhaXQgZm9yIGl0IHRvIGJlIGNyZWF0ZWRcbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFwYXJlbnRRdWV1ZS5oYXModGFiLm9wZW5lclRhYklkKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGFyZW50UXVldWUuc2V0KHRhYi5vcGVuZXJUYWJJZCwgW10pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vIHNob3VsZCBiZSBqdXN0IHBhcmVudFF1ZXVlLmdldCh0YWIub3BlbmVyVGFiSWQpLnB1c2godGFiT2JqKVxuICAgICAgICAgICAgICAgICAgICB2YXIgc2libGluZ3BhcmVudFF1ZXVlID0gcGFyZW50UXVldWUuZ2V0KHRhYi5vcGVuZXJUYWJJZCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzaWJsaW5ncGFyZW50UXVldWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpYmxpbmdwYXJlbnRRdWV1ZS5wdXNoKHRhYk9iaik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBUb3AgbGV2ZWwgdGFiIC0+IHBhcmVudCB0byB3aW5kb3cncyByb290IHRhYlxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdmFyIHdpbmRvd18xID0gdGFiT2JqLmdldFdpbmRvdygpO1xuICAgICAgICAgICAgICAgIHRhYk9iai5wYXJlbnRUbyh3aW5kb3dfMS5yb290KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhciBxdWV1ZUZvclRoaXMgPSBwYXJlbnRRdWV1ZS5nZXQodGFiT2JqLmlkKTtcbiAgICAgICAgICAgIGlmIChxdWV1ZUZvclRoaXMpIHtcbiAgICAgICAgICAgICAgICAvLyBDaGlsZHJlbiB3ZXJlIGNyZWF0ZWQgZmlyc3QgLT4gcGFyZW50IHRoZW1cbiAgICAgICAgICAgICAgICBxdWV1ZUZvclRoaXMuZm9yRWFjaChmdW5jdGlvbiAodGFiKSB7XG4gICAgICAgICAgICAgICAgICAgIHRhYi5wYXJlbnRUbyh0YWJPYmopO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3RoaXMuYWRkKHRhYk9iaik7XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgcmV0dXJuIFRhYkNvbnRhaW5lcjtcbn0oKSk7XG5leHBvcnRzLlRhYkNvbnRhaW5lciA9IFRhYkNvbnRhaW5lcjtcbi8vIENvbnRhaW5zIHJlZmVyZW5jZXMgdG8gYWxsIHRhYnMgZnJvbSBlYWNoIHdpbmRvd1xuZXhwb3J0cy50YWJDb250YWluZXIgPSBuZXcgVGFiQ29udGFpbmVyKCk7XG5cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL2FwcC9zY3JpcHRzL1RhYkNvbnRhaW5lci50c1xuLy8gbW9kdWxlIGlkID0gMFxuLy8gbW9kdWxlIGNodW5rcyA9IDAgMSAyIDMgNCA1IDYiLCJPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG52YXIgVGFiQ29udGFpbmVyXzEgPSByZXF1aXJlKFwiLi9UYWJDb250YWluZXJcIik7XG52YXIgQ29tbWFuZF8xID0gcmVxdWlyZShcIi4vQ29tbWFuZFwiKTtcbnZhciBXaW5kb3dDb250YWluZXJfMSA9IHJlcXVpcmUoXCIuL1dpbmRvd0NvbnRhaW5lclwiKTtcbnZhciBUYWIgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gVGFiKGNocm9tZVRhYikge1xuICAgICAgICBpZiAoY2hyb21lVGFiKSB7XG4gICAgICAgICAgICBpZiAoY2hyb21lVGFiLmlkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pZCA9IGNocm9tZVRhYi5pZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIFwiVW5kZXIgc29tZSBjaXJjdW1zdGFuY2VzIGEgdGFiIG1heSBub3QgYmUgYXNzaWduZWQgYW4gSUQgZm9yIGV4YW1wbGUsXG4gICAgICAgICAgICAgICAgLy8gd2hlbiBxdWVyeWluZyBmb3JlaWduIHRhYnMgdXNpbmcgdGhlIHNlc3Npb25zIEFQSVwiXG4gICAgICAgICAgICAgICAgLy8gc2hvdWxkIG5ldmVyIGhhcHBlbiBoZXJlXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyB0YWIgaWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuY2hyb21lVGFiID0gY2hyb21lVGFiO1xuICAgICAgICAgICAgdGhpcy5pbml0aWFsSW5kZXggPSBjaHJvbWVUYWIuaW5kZXg7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmlzUm9vdCA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLmlkID0gMDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNoaWxkcmVuID0gbmV3IFRhYkNvbnRhaW5lcl8xLlRhYkNvbnRhaW5lcigpO1xuICAgICAgICB0aGlzLmNsb3NlQ2hpbGRyZW5CdXR0b25WaXNpYmxlID0gZmFsc2U7XG4gICAgfVxuICAgIC8vIENhbGwgZnVuY3Rpb24gb24gZXZlcnkgY2hpbGQgKGJ1dCBub3QgY2hpbGRyZW4gb2YgY2hpbGRyZW4pXG4gICAgVGFiLnByb3RvdHlwZS5hcHBseUNoaWxkcmVuID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gICAgICAgIHRoaXMuY2hpbGRyZW4uYXBwbHlBbGwoY2FsbGJhY2spO1xuICAgIH07XG4gICAgLy8gQ2FsbCBmdW5jdGlvbiBvbiBldmVyeSBkZXNjZW5kYW50IChjaGlsZHJlbiwgY2hpbGRyZW4gb2YgY2hpbGRyZW5cbiAgICBUYWIucHJvdG90eXBlLmFwcGx5RGVzY2VuZGFudHMgPSBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgICAgICAgdGhpcy5jaGlsZHJlbi50YWJzLmZvckVhY2goZnVuY3Rpb24gKHRhYikge1xuICAgICAgICAgICAgY2FsbGJhY2sodGFiKTtcbiAgICAgICAgICAgIHJldHVybiB0YWIuYXBwbHlEZXNjZW5kYW50cyhjYWxsYmFjayk7XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgLy8gU2VuZCB0YWIgc3BlY2lmaWMgY29tbWFuZCB0byBCcm93c2VyaG9va1xuICAgIFRhYi5wcm90b3R5cGUuY29tbWFuZCA9IGZ1bmN0aW9uIChjb21tYW5kLCBwYXJhbWV0ZXJzKSB7XG4gICAgICAgIGlmIChwYXJhbWV0ZXJzID09PSB2b2lkIDApIHsgcGFyYW1ldGVycyA9IHt9OyB9XG4gICAgICAgIHBhcmFtZXRlcnNbJ3RhYklkJ10gPSB0aGlzLmlkO1xuICAgICAgICB2YXIgY21kID0gbmV3IENvbW1hbmRfMS5kZWZhdWx0KGNvbW1hbmQsIHBhcmFtZXRlcnMpO1xuICAgICAgICBjbWQuc2VuZCh0aGlzLmdldFdpbmRvdygpKTtcbiAgICB9O1xuICAgIC8vIFRyYXZlcnNlIHRvIHJvb3QsIHJldHVybiBkaXN0YW5jZSAvIGRlcHRoIC8gaW5kZW50bGV2ZWwgICoqL1xuICAgIC8qIGVnOlxuICAgICAgLWE6IHJvb3RcbiAgICAgICAgIC0gYjogZGlzdGFuY2UgdG8gcm9vdDogMVxuICAgICAgICAgLSBjOiBkaXN0YW5jZSB0byByb290OiAxXG4gICAgICAgICAgIC0gZDogZGlzdGFuY2UgdG8gcm9vdDogMlxuICAgICovXG4gICAgVGFiLnByb3RvdHlwZS5jYWxjdWxhdGVEaXN0YW5jZVRvUm9vdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGhlbHBlciA9IGZ1bmN0aW9uICh0YWIsIGRpc3RhbmNlKSB7XG4gICAgICAgICAgICBpZiAodGFiLnBhcmVudCkge1xuICAgICAgICAgICAgICAgIGlmICh0YWIucGFyZW50LmlzUm9vdCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaGVscGVyKHRhYi5wYXJlbnQsIGRpc3RhbmNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBoZWxwZXIodGFiLnBhcmVudCwgKytkaXN0YW5jZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGRpc3RhbmNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gaGVscGVyKHRoaXMsIDApO1xuICAgIH07XG4gICAgVGFiLnByb3RvdHlwZS5kZXB0aCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2FsY3VsYXRlRGlzdGFuY2VUb1Jvb3QoKTtcbiAgICB9O1xuICAgIFRhYi5wcm90b3R5cGUuZ2V0V2luZG93ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgd2luZG93SWQgPSB0aGlzLmNocm9tZVRhYi53aW5kb3dJZDtcbiAgICAgICAgcmV0dXJuIFdpbmRvd0NvbnRhaW5lcl8xLndpbmRvd0NvbnRhaW5lci5nZXQod2luZG93SWQpO1xuICAgIH07XG4gICAgVGFiLnByb3RvdHlwZS5wYXJlbnRUbyA9IGZ1bmN0aW9uIChwYXJlbnQpIHtcbiAgICAgICAgLy8gQWRkIHRhYiB0byBuZXcgcGFyZW50J3MgY2hpbGQgbGlzdFxuICAgICAgICBwYXJlbnQuY2hpbGRyZW4uYWRkKHRoaXMpO1xuICAgICAgICB0aGlzLnBhcmVudCA9IHBhcmVudDtcbiAgICAgICAgLy8gSGFzIGNoaWxkcmVuIG5vdyAtPiBzaG93IGNsb3NlIGNoaWxkcmVuIGJ1dHRvblxuICAgICAgICAvLyBpZiAoIXBhcmVudC5pc1Jvb3QgJiYgIXBhcmVudC5jbG9zZUNoaWxkcmVuQnV0dG9uVmlzaWJsZSkge1xuICAgICAgICBpZiAoIXBhcmVudC5pc1Jvb3QpIHtcbiAgICAgICAgICAgIHBhcmVudC5zaG93Q2xvc2VDaGlsZHJlbkJ1dHRvbigpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgLy8gUmVtb3ZlIHRhYiBhbmQgcGFyZW50IGl0J3MgY2hpbGRyZW4gdG8gb3duIHBhcmVudFxuICAgIFRhYi5wcm90b3R5cGUucmVtb3ZlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAvLyBQYXJlbnQgcmVtb3ZlZCB0YWIncyBjaGlsZHJlbiB0byBvd24gcGFyZW50IGFuZCByZWRyYXdcbiAgICAgICAgdGhpcy5hcHBseURlc2NlbmRhbnRzKGZ1bmN0aW9uIChjaGlsZCkge1xuICAgICAgICAgICAgLy8gUmVwYXJlbnQgZGlyZWN0IGNoaWxkcmVuXG4gICAgICAgICAgICBpZiAoY2hpbGQucGFyZW50LmlkID09PSBfdGhpcy5pZCkge1xuICAgICAgICAgICAgICAgIGNoaWxkLnBhcmVudFRvKF90aGlzLnBhcmVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBSZS1yZW5kZXIgYWxsIGRlc2NlbmRhbnRzIHNpbmNlIHRoZWlyIGluZGVudGF0aW9uIGhhcyBjaGFuZ2VkLCAgICAgIC8vIHdoaWxlIHBhcmVudCBzdGF5ZWQgdGhlIHNhbWUuXG4gICAgICAgICAgICBjaGlsZC5yZW5kZXJJbmRlbnRhdGlvbigpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5wYXJlbnQuY2hpbGRyZW4ucmVtb3ZlKHRoaXMpOyAvLyByZW1vdmUgZnJvbSBwYXJlbnQncyBjaGlsZHJlblxuICAgICAgICAvLyBUaGUgbGFzdCBjaGlsZCB3YXMgcmVtb3ZlZCAtPiBoaWRlIGNsb3NlIGNoaWxkcmVuIGJ1dHRvblxuICAgICAgICBpZiAoIXRoaXMucGFyZW50LmlzUm9vdCAmJiB0aGlzLnBhcmVudC5jaGlsZHJlbi5pc0VtcHR5KCkpIHtcbiAgICAgICAgICAgIHRoaXMucGFyZW50LmhpZGVDbG9zZUNoaWxkcmVuQnV0dG9uKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFRhYi5wcm90b3R5cGUucmVtb3ZlQ2hpbGRyZW4gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMuYXBwbHlEZXNjZW5kYW50cyhmdW5jdGlvbiAoY2hpbGQpIHtcbiAgICAgICAgICAgIGNocm9tZS50YWJzLnJlbW92ZShjaGlsZC5pZCk7XG4gICAgICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0Vycm9yIG9uIHJlbW92ZUNoaWxkcmVuJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgLy8gQ2FsbGVkIG9uIGVhY2ggdGFiIGFmdGVyIHRhYiBjb250YWluZXIgcmVhcHBlYXIgaXMgcmVkcmF3bi5cbiAgICBUYWIucHJvdG90eXBlLnJlbmRlckV2ZXJ5dGhpbmcgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmICghdGhpcy5jaGlsZHJlbi5pc0VtcHR5KCkpIHtcbiAgICAgICAgICAgIHRoaXMuY29tbWFuZCgnU2hvd0Nsb3NlQ2hpbGRyZW5CdXR0b24nKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnJlbmRlckluZGVudGF0aW9uKCk7XG4gICAgfTtcbiAgICBUYWIucHJvdG90eXBlLnNob3dDbG9zZUNoaWxkcmVuQnV0dG9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLmNvbW1hbmQoJ1Nob3dDbG9zZUNoaWxkcmVuQnV0dG9uJyk7XG4gICAgICAgIHRoaXMuY2xvc2VDaGlsZHJlbkJ1dHRvblZpc2libGUgPSB0cnVlO1xuICAgIH07XG4gICAgVGFiLnByb3RvdHlwZS5oaWRlQ2xvc2VDaGlsZHJlbkJ1dHRvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5jb21tYW5kKCdIaWRlQ2xvc2VDaGlsZHJlbkJ1dHRvbicpO1xuICAgICAgICB0aGlzLmNsb3NlQ2hpbGRyZW5CdXR0b25WaXNpYmxlID0gZmFsc2U7XG4gICAgfTtcbiAgICBUYWIucHJvdG90eXBlLnJlbmRlckluZGVudGF0aW9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgZGVwdGggPSB0aGlzLmRlcHRoKCk7XG4gICAgICAgIHRoaXMuY29tbWFuZCgnSW5kZW50VGFiJywgeyAnaW5kZW50TGV2ZWwnOiBkZXB0aCB9KTtcbiAgICB9O1xuICAgIHJldHVybiBUYWI7XG59KCkpO1xuZXhwb3J0cy5kZWZhdWx0ID0gVGFiO1xuXG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gLi9hcHAvc2NyaXB0cy9UYWIudHNcbi8vIG1vZHVsZSBpZCA9IDFcbi8vIG1vZHVsZSBjaHVua3MgPSAwIDEgMiAzIDQgNSA2IiwidmFyIF9fYXNzaWduID0gKHRoaXMgJiYgdGhpcy5fX2Fzc2lnbikgfHwgZnVuY3Rpb24gKCkge1xuICAgIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbih0KSB7XG4gICAgICAgIGZvciAodmFyIHMsIGkgPSAxLCBuID0gYXJndW1lbnRzLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcbiAgICAgICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSlcbiAgICAgICAgICAgICAgICB0W3BdID0gc1twXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdDtcbiAgICB9O1xuICAgIHJldHVybiBfX2Fzc2lnbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbnZhciBUYWJDb250YWluZXJfMSA9IHJlcXVpcmUoXCIuL1RhYkNvbnRhaW5lclwiKTtcbnZhciBDb21tYW5kID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIENvbW1hbmQoY29tbWFuZCwgcGFyYW1ldGVycykge1xuICAgICAgICB0aGlzLmNvbW1hbmQgPSBjb21tYW5kO1xuICAgICAgICB0aGlzLnBhcmFtZXRlcnMgPSBwYXJhbWV0ZXJzO1xuICAgICAgICB0aGlzLmxvZ0VuYWJsZWQgPSB0cnVlO1xuICAgIH1cbiAgICAvLyBTZW5kIGNvbW1hbmQgdG8gd2luZG93IHZpYSBDaHJvbWUgZXh0ZXJuYWwgbWVzc2FnaW5nIEFQSVxuICAgIENvbW1hbmQucHJvdG90eXBlLnNlbmQgPSBmdW5jdGlvbiAod2luZG93KSB7XG4gICAgICAgIHZhciBwYXJhbWV0ZXJzID0gX19hc3NpZ24oX19hc3NpZ24oe30sIHRoaXMucGFyYW1ldGVycyksIHsgY29tbWFuZDogdGhpcy5jb21tYW5kIH0pO1xuICAgICAgICBpZiAoIXdpbmRvdy5pc0Nvbm5lY3RlZCgpKSB7XG4gICAgICAgICAgICB3aW5kb3cuY29ubmVjdCgpO1xuICAgICAgICAgICAgaWYgKCF3aW5kb3cuaXNDb25uZWN0ZWQoKSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0NhbnQgY29ubmVjdCB0byB3aW5kb3cnLCB3aW5kb3cpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB2YXIgc3VjY2VzcyA9IHdpbmRvdy5jb25uZWN0aW9uLnNlbmRNZXNzYWdlKHBhcmFtZXRlcnMpO1xuICAgICAgICBpZiAoIXN1Y2Nlc3MpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0NvbW1hbmQgY291bGRuXFwndCBiZSBzZW50Jyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMubG9nRW5hYmxlZCkge1xuICAgICAgICAgICAgY29uc29sZS50YWJsZShwYXJhbWV0ZXJzKTtcbiAgICAgICAgICAgIHZhciBsb2dMaW5lID0gc3VjY2VzcyA/ICdTZW50IHRvJyA6ICdGYWlsZWQgdG8gc2VuZCc7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhsb2dMaW5lLCB3aW5kb3cpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvLyBDb21tYW5kcyByZWNlaXZlZCBmcm9tIGJyb3dzZXJob29rXG4gICAgQ29tbWFuZC5vblJlY2VpdmVkID0gZnVuY3Rpb24gKHJlcXVlc3QpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ0NvbW1hbmQgcmVjZWl2ZWQnLCByZXF1ZXN0KTtcbiAgICAgICAgc3dpdGNoIChyZXF1ZXN0LmNvbW1hbmQpIHtcbiAgICAgICAgICAgIGNhc2UgJ0Nsb3NlQ2hpbGRyZW4nOlxuICAgICAgICAgICAgICAgIHZhciB0YWIgPSBUYWJDb250YWluZXJfMS50YWJDb250YWluZXIuZ2V0KHJlcXVlc3QudGFiSWQpO1xuICAgICAgICAgICAgICAgIHRhYi5yZW1vdmVDaGlsZHJlbigpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnUmVuZGVyQWxsVGFicyc6XG4gICAgICAgICAgICAgICAgVGFiQ29udGFpbmVyXzEudGFiQ29udGFpbmVyLmFwcGx5QWxsKGZ1bmN0aW9uICh0YWIpIHsgcmV0dXJuIHRhYi5yZW5kZXJFdmVyeXRoaW5nKCk7IH0pO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdVbmtub3duIGNvbW1hbmQ6ICcgKyByZXF1ZXN0LmNvbW1hbmQpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gQ29tbWFuZDtcbn0oKSk7XG5leHBvcnRzLmRlZmF1bHQgPSBDb21tYW5kO1xuXG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gLi9hcHAvc2NyaXB0cy9Db21tYW5kLnRzXG4vLyBtb2R1bGUgaWQgPSAyXG4vLyBtb2R1bGUgY2h1bmtzID0gMCAxIDIgMyA0IDUgNiIsIk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMud2luZG93Q29udGFpbmVyID0gdm9pZCAwO1xudmFyIFdpbmRvd18xID0gcmVxdWlyZShcIi4vV2luZG93XCIpO1xudmFyIFdpbmRvd0NvbnRhaW5lciA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBXaW5kb3dDb250YWluZXIoKSB7XG4gICAgICAgIHRoaXMud2luZG93cyA9IG5ldyBNYXAoKTtcbiAgICB9XG4gICAgV2luZG93Q29udGFpbmVyLnByb3RvdHlwZS5hZGQgPSBmdW5jdGlvbiAod2luZG93KSB7XG4gICAgICAgIHZhciBrZXkgPSB3aW5kb3cuaWQ7XG4gICAgICAgIHRoaXMud2luZG93cy5zZXQoa2V5LCB3aW5kb3cpO1xuICAgIH07XG4gICAgV2luZG93Q29udGFpbmVyLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgdmFyIHdpbmRvdyA9IHRoaXMud2luZG93cy5nZXQoaWQpO1xuICAgICAgICBpZiAoIXdpbmRvdykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdXaW5kb3dDb250YWluZXI6IGFjY2VzcyB0byBtaXNzaW5nIGVsZW1lbnQuIGlkOiAgJyArIGlkKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gd2luZG93O1xuICAgIH07XG4gICAgV2luZG93Q29udGFpbmVyLnByb3RvdHlwZS5yZW1vdmUgPSBmdW5jdGlvbiAod2luZG93KSB7XG4gICAgICAgIHRoaXMud2luZG93cy5kZWxldGUod2luZG93LmlkKTtcbiAgICB9O1xuICAgIFdpbmRvd0NvbnRhaW5lci5wcm90b3R5cGUuaW5pdEZyb21BcnJheSA9IGZ1bmN0aW9uICh3aW5kb3dzKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHdpbmRvd3MuZm9yRWFjaChmdW5jdGlvbiAoY2hyb21lV2luZG93KSB7XG4gICAgICAgICAgICAvLyBjb25uZWN0KCkgZG9lc24ndCB3b3JrIGhlcmUgZHVlIHRvIGEgcmFjZS1jb25kaXRpb24gd2l0aCBtZXNzYWdpbmcuXG4gICAgICAgICAgICAvLyBUcnkgY29ubmVjdGluZyB3aGVuIHRoZSBtZXNzYWdlLWJyaWRnZSBpcyBhY3R1YWxseSBuZWVkZWQ7IENvbW1hbmQjc2VuZCgpXG4gICAgICAgICAgICB2YXIgd2luZG93ID0gV2luZG93XzEuZGVmYXVsdC5pbml0KGNocm9tZVdpbmRvdyk7XG4gICAgICAgICAgICBfdGhpcy5hZGQod2luZG93KTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICByZXR1cm4gV2luZG93Q29udGFpbmVyO1xufSgpKTtcbmV4cG9ydHMud2luZG93Q29udGFpbmVyID0gbmV3IFdpbmRvd0NvbnRhaW5lcigpO1xuXG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gLi9hcHAvc2NyaXB0cy9XaW5kb3dDb250YWluZXIudHNcbi8vIG1vZHVsZSBpZCA9IDNcbi8vIG1vZHVsZSBjaHVua3MgPSAwIDEgMiAzIDQgNSA2IiwiT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIFRhYl8xID0gcmVxdWlyZShcIi4vVGFiXCIpO1xudmFyIENvbm5lY3Rpb25fMSA9IHJlcXVpcmUoXCIuL0Nvbm5lY3Rpb25cIik7XG52YXIgV2luZG93ID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFdpbmRvdyhpZCwgY2hyb21lV2luZG93KSB7XG4gICAgICAgIHRoaXMuaWQgPSBpZDtcbiAgICAgICAgdGhpcy5jaHJvbWVXaW5kb3cgPSBjaHJvbWVXaW5kb3c7XG4gICAgICAgIHRoaXMucm9vdCA9IG5ldyBUYWJfMS5kZWZhdWx0KCk7XG4gICAgfVxuICAgIFdpbmRvdy5pbml0ID0gZnVuY3Rpb24gKGNocm9tZVdpbmRvdykge1xuICAgICAgICByZXR1cm4gbmV3IFdpbmRvdyhjaHJvbWVXaW5kb3cuaWQsIGNocm9tZVdpbmRvdyk7XG4gICAgfTtcbiAgICAvLyBPcGVuIG1lc3NhZ2luZyBwb3J0IGJldHdlZW4gYnJvd3NlciB3aW5kb3cgYW5kIGV4dGVuc2lvblxuICAgIFdpbmRvdy5wcm90b3R5cGUuY29ubmVjdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHBvcnROYW1lID0gXCJ3aW5kb3ctXCIgKyB0aGlzLmlkO1xuICAgICAgICB0aGlzLmNvbm5lY3Rpb24gPSBuZXcgQ29ubmVjdGlvbl8xLmRlZmF1bHQoKTtcbiAgICAgICAgdGhpcy5jb25uZWN0aW9uLmNvbm5lY3QoeyBuYW1lOiBwb3J0TmFtZSB9KTtcbiAgICB9O1xuICAgIFdpbmRvdy5wcm90b3R5cGUub25SZW1vdmVkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLnJvb3QuYXBwbHlEZXNjZW5kYW50cyhmdW5jdGlvbiAodGFiKSB7IHJldHVybiB0YWIucmVtb3ZlKCk7IH0pO1xuICAgIH07XG4gICAgV2luZG93LnByb3RvdHlwZS5pc0Nvbm5lY3RlZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29ubmVjdGlvbiAhPT0gdW5kZWZpbmVkO1xuICAgIH07XG4gICAgcmV0dXJuIFdpbmRvdztcbn0oKSk7XG5leHBvcnRzLmRlZmF1bHQgPSBXaW5kb3c7XG5cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL2FwcC9zY3JpcHRzL1dpbmRvdy50c1xuLy8gbW9kdWxlIGlkID0gNFxuLy8gbW9kdWxlIGNodW5rcyA9IDAgMSAyIDMgNCA1IDYiLCJPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG52YXIgQ29tbWFuZF8xID0gcmVxdWlyZShcIi4vQ29tbWFuZFwiKTtcbnZhciBDb25uZWN0aW9uID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIENvbm5lY3Rpb24oKSB7XG4gICAgICAgIC8vIFBvcnQgaXMgYWN0aXZlIGFmdGVyIE9LIG1lc3NhZ2UgaXMgcmVjZWl2ZWQgZnJvbSBVc2VyU2NyaXB0XG4gICAgICAgIC8vIGFuZCBubyBkaXNjb25uZWN0IGV2ZW50IGhhdmUgYmVlbiByZWNlaXZlZFxuICAgICAgICB0aGlzLl9pc0FjdGl2ZSA9IGZhbHNlO1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQ29ubmVjdGlvbi5wcm90b3R5cGUsIFwicG9ydFwiLCB7XG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3BvcnQ7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQ29ubmVjdGlvbi5wcm90b3R5cGUsIFwiaXNEaXNjb25uZWN0ZWRcIiwge1xuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9pc0Rpc2Nvbm5lY3RlZDtcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShDb25uZWN0aW9uLnByb3RvdHlwZSwgXCJpc0FjdGl2RVwiLCB7XG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2lzQWN0aXZlO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSk7XG4gICAgQ29ubmVjdGlvbi5wcm90b3R5cGUuYWRkTGlzdGVuZXJzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLnBvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKHRoaXMub25EaXNjb25uZWN0KTtcbiAgICAgICAgdGhpcy5wb3J0Lm9uTWVzc2FnZS5hZGRMaXN0ZW5lcih0aGlzLm9uTWVzc2FnZSk7XG4gICAgfTtcbiAgICBDb25uZWN0aW9uLnByb3RvdHlwZS5vbk1lc3NhZ2UgPSBmdW5jdGlvbiAobWVzc2FnZSwgX3BvcnQpIHtcbiAgICAgICAgLy8gVE9ETzogQ29tbWFuZCBwYXJzaW5nICsgZGVmaW5pdGlvbnNcbiAgICAgICAgaWYgKG1lc3NhZ2UgPT0gJ09LJykge1xuICAgICAgICAgICAgdGhpcy5faXNBY3RpdmUgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lc3NhZ2UgPT0gJ0FDSycgfHwgbWVzc2FnZSA9PSAnTkFDSycpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdFeHRlbnNpb24gcmVwbHkgOiAnICsgbWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVzc2FnZS5jb21tYW5kKSB7XG4gICAgICAgICAgICBDb21tYW5kXzEuZGVmYXVsdC5vblJlY2VpdmVkKG1lc3NhZ2UpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBDb25uZWN0aW9uLnByb3RvdHlwZS5zZW5kTWVzc2FnZSA9IGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgICAgIHRoaXMuX3BvcnQucG9zdE1lc3NhZ2UobWVzc2FnZSk7XG4gICAgICAgIHJldHVybiBjaHJvbWUucnVudGltZS5sYXN0RXJyb3IgPT09IHVuZGVmaW5lZDtcbiAgICB9O1xuICAgIENvbm5lY3Rpb24ucHJvdG90eXBlLm9uRGlzY29ubmVjdCA9IGZ1bmN0aW9uIChwb3J0KSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdQb3J0IGRpc2Nvbm5lY3RlZCcsIHBvcnQpO1xuICAgICAgICB0aGlzLl9pc0Rpc2Nvbm5lY3RlZCA9IHRydWU7XG4gICAgICAgIHRoaXMuX2lzQWN0aXZlID0gZmFsc2U7XG4gICAgfTtcbiAgICAvLyBDb25uZWN0SW5mbyBpcyB1c2VkIHRvIHNldCBwb3J0IG5hbWVcbiAgICAvLyBDdXJyZW50IG5hbWUgZm9ybWF0IGlzOiBgd2luZG93LTx3aW5kb3cuaWQ+YFxuICAgIC8vIE5hbWUgaXMgdXNlZCBpbiB1c2VyIHNjcmlwdCB0byBtYXRjaCBtZXNzYWdpbmcgcG9ydHMgYW5kIGJyb3dzaW5nIHdpbmRvd3NcbiAgICBDb25uZWN0aW9uLnByb3RvdHlwZS5jb25uZWN0ID0gZnVuY3Rpb24gKGluZm8pIHtcbiAgICAgICAgLy8gVml2YWxkaSdzIGV4dGVuc2lvbiBpZC4gUHJvYmFibHkgc2hvdWxkbid0IGJlIGhhcmRjb2RlZC5cbiAgICAgICAgdmFyIGV4dElkID0gJ21wb2dub2Jia2lsZGprb2ZhamlmcGRmaGNva2xpbWxpJztcbiAgICAgICAgdGhpcy5fcG9ydCA9IGNocm9tZS5ydW50aW1lLmNvbm5lY3QoZXh0SWQsIGluZm8pO1xuICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nvbm5lY3QgZmFpbGVkIHRvIGJyb3dzZXIuaHRtbC4nXG4gICAgICAgICAgICAgICAgKyAnSXMgYnJvd3Nlcmhvb2sgaW5zdGFsbGVkPyBjaHJvbWUucnVudGltZS5sYXN0RXJyb3I6ICdcbiAgICAgICAgICAgICAgICArIGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmFkZExpc3RlbmVycygpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gQ29ubmVjdGlvbjtcbn0oKSk7XG5leHBvcnRzLmRlZmF1bHQgPSBDb25uZWN0aW9uO1xuXG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gLi9hcHAvc2NyaXB0cy9Db25uZWN0aW9uLnRzXG4vLyBtb2R1bGUgaWQgPSA1XG4vLyBtb2R1bGUgY2h1bmtzID0gMCAxIDIgMyA0IDUgNiIsIk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbnJlcXVpcmUoXCJjaHJvbWVyZWxvYWQvZGV2b25seVwiKTsgLy8gUmVtb3ZlIHRoaXMgYmVmb3JlIGJ1aWxkaW5nXG52YXIgVGFiXzEgPSByZXF1aXJlKFwiLi9UYWJcIik7XG52YXIgVGFiQ29udGFpbmVyXzEgPSByZXF1aXJlKFwiLi9UYWJDb250YWluZXJcIik7XG52YXIgV2luZG93Q29udGFpbmVyXzEgPSByZXF1aXJlKFwiLi9XaW5kb3dDb250YWluZXJcIik7XG52YXIgV2luZG93XzEgPSByZXF1aXJlKFwiLi9XaW5kb3dcIik7XG52YXIgQ2hyb21lQ2FsbGJhY2tzID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIENocm9tZUNhbGxiYWNrcygpIHtcbiAgICB9XG4gICAgQ2hyb21lQ2FsbGJhY2tzLm9uVGFiQ3JlYXRlZCA9IGZ1bmN0aW9uIChjaHJvbWVUYWIpIHtcbiAgICAgICAgdmFyIHRhYiA9IG5ldyBUYWJfMS5kZWZhdWx0KGNocm9tZVRhYik7XG4gICAgICAgIFRhYkNvbnRhaW5lcl8xLnRhYkNvbnRhaW5lci5hZGQodGFiKTtcbiAgICAgICAgLy8gY2hpbGQgdGFiIGNyZWF0ZWQgLT4gc2V0IHBhcmVudCBhbmQgaW5kZW50LlxuICAgICAgICBpZiAoY2hyb21lVGFiLm9wZW5lclRhYklkKSB7XG4gICAgICAgICAgICB2YXIgcGFyZW50VGFiID0gVGFiQ29udGFpbmVyXzEudGFiQ29udGFpbmVyLmdldChjaHJvbWVUYWIub3BlbmVyVGFiSWQpO1xuICAgICAgICAgICAgdGFiLnBhcmVudFRvKHBhcmVudFRhYik7XG4gICAgICAgICAgICB0YWIucmVuZGVySW5kZW50YXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgICAvLyB0b3AgbGV2ZWwgdGFiIC0+IHBhcmVudCB0byB3aW5kb3cncyByb290IG5vZGVcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB2YXIgcm9vdCA9IHRhYi5nZXRXaW5kb3coKS5yb290O1xuICAgICAgICAgICAgdGFiLnBhcmVudFRvKHJvb3QpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBDaHJvbWVDYWxsYmFja3Mub25UYWJNb3ZlZCA9IGZ1bmN0aW9uICh0YWJJZCwgaW5mbykge1xuICAgICAgICB2YXIgdGFiID0gVGFiQ29udGFpbmVyXzEudGFiQ29udGFpbmVyLmdldCh0YWJJZCk7XG4gICAgICAgIHZhciByb290ID0gdGFiLmdldFdpbmRvdygpLnJvb3Q7XG4gICAgICAgIC8vIHdoZXRoZXIgdGhpcyB3YXMgZmluYWwgbW92ZSBldmVudCBtYWRlIGJ5IFZpdmFsZGlcbiAgICAgICAgdmFyIGNvcnJlY3RFdmVudCA9IHRhYi5pbml0aWFsSW5kZXggPT09IGluZm8uZnJvbUluZGV4O1xuICAgICAgICAvLyB0b3AgbGV2ZWwgdGFiIG5lZWRzIHRvIHJlcG9zaXRpb25lZCBvdXRzaWRlIGV4aXN0aW5nIGJyYW5jaGVzXG4gICAgICAgIGlmICh0YWIucGFyZW50LmlzUm9vdCAmJiBjb3JyZWN0RXZlbnQpIHtcbiAgICAgICAgICAgIHZhciBzZWFyY2hCZWxvd18xID0gaW5mby50b0luZGV4OyAvLyBzZWFyY2ggZm9yIHNwb3QgYmVsb3cgY3JlYXRlZCB0YWJcbiAgICAgICAgICAgIHZhciBwcm9jZXNzZWRfMSA9IDA7XG4gICAgICAgICAgICB2YXIgbWluSW5kZXhfMTtcbiAgICAgICAgICAgIC8vIFRoaXMgbGFncyBzb21ldGltZXMuXG4gICAgICAgICAgICAvLyBUT0RPOiBrZWVwIHRyYWNrIG9mIHRhYiBvcmRlciB0byBhdm9pZCBhcGkgY2FsbD9cbiAgICAgICAgICAgIC8vIFRPRE86IEZpZ3VyZSBvdXQgd2hhdCB0aGlzIGRvZXMgYW5kIHJld3JpdGVcbiAgICAgICAgICAgIHJvb3QuY2hpbGRyZW4udGFicy5mb3JFYWNoKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgICAgICAgLy8gZ2V0IGN1cnJlbnQgaW5kZXhcbiAgICAgICAgICAgICAgICBjaHJvbWUudGFicy5nZXQoaXRlbS5pZCwgZnVuY3Rpb24gKHRhYikge1xuICAgICAgICAgICAgICAgICAgICB2YXIgcHJldiA9IC0tdGFiLmluZGV4O1xuICAgICAgICAgICAgICAgICAgICBpZiAocHJldiA+IHNlYXJjaEJlbG93XzEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghbWluSW5kZXhfMSB8fCBwcmV2IDw9IG1pbkluZGV4XzEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5JbmRleF8xID0gcHJldjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChwcmV2ID09PSBzZWFyY2hCZWxvd18xKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5JbmRleF8xID0gcHJldjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBwcm9jZXNzZWRfMSsrO1xuICAgICAgICAgICAgICAgICAgICBpZiAocHJvY2Vzc2VkXzEgPT09IHJvb3QuY2hpbGRyZW4udGFicy5zaXplKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5JbmRleF8xID0gKG1pbkluZGV4XzEpID8gbWluSW5kZXhfMSA6IDk5OTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNocm9tZS50YWJzLm1vdmUoW2l0ZW0uaWRdLCB7IGluZGV4OiBtaW5JbmRleF8xIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgQ2hyb21lQ2FsbGJhY2tzLm9uVGFiUmVtb3ZlZCA9IGZ1bmN0aW9uICh0YWJJZCkge1xuICAgICAgICB2YXIgdGFiID0gVGFiQ29udGFpbmVyXzEudGFiQ29udGFpbmVyLmdldCh0YWJJZCk7XG4gICAgICAgIGlmICghdGFiKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB0YWIucmVtb3ZlKCk7XG4gICAgICAgIFRhYkNvbnRhaW5lcl8xLnRhYkNvbnRhaW5lci5yZW1vdmUodGFiKTtcbiAgICB9O1xuICAgIC8vIFRhYiBtb3ZlZCB0byBuZXcgd2luZG93IC0+IHJlcGFyZW50IHRvIG5ldyBXaW5kb3cncyByb290XG4gICAgQ2hyb21lQ2FsbGJhY2tzLm9uVGFiQXR0YWNoZWQgPSBmdW5jdGlvbiAodGFiSWQsIGluZm8pIHtcbiAgICAgICAgdmFyIHRhYiA9IFRhYkNvbnRhaW5lcl8xLnRhYkNvbnRhaW5lci5nZXQodGFiSWQpO1xuICAgICAgICBpZiAoIXRhYilcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgdmFyIG5ld1dpbmRvdyA9IFdpbmRvd0NvbnRhaW5lcl8xLndpbmRvd0NvbnRhaW5lci5nZXQoaW5mby5uZXdXaW5kb3dJZCk7XG4gICAgICAgIHRhYi5wYXJlbnRUbyhuZXdXaW5kb3cucm9vdCk7XG4gICAgICAgIHRhYi5yZW5kZXJJbmRlbnRhdGlvbigpO1xuICAgIH07XG4gICAgLy8gbW92ZSBjaGlsZHJlbiB0byBuZXcgd2luZG93IHdpdGggdGhlaXIgcGFyZW50P1xuICAgIENocm9tZUNhbGxiYWNrcy5vblRhYkRldGFjaGVkID0gZnVuY3Rpb24gKHRhYklkLCBfaW5mbykge1xuICAgICAgICB2YXIgdGFiID0gVGFiQ29udGFpbmVyXzEudGFiQ29udGFpbmVyLmdldCh0YWJJZCk7XG4gICAgICAgIGlmICghdGFiKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB0YWIuY2hpbGRyZW4udGFicy5mb3JFYWNoKGZ1bmN0aW9uIChjaGlsZCkge1xuICAgICAgICAgICAgY2hpbGQucGFyZW50VG8odGFiLnBhcmVudCk7XG4gICAgICAgICAgICBjaGlsZC5yZW5kZXJJbmRlbnRhdGlvbigpO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLmNocm9tZS5jb20vZG9jcy9leHRlbnNpb25zL3JlZmVyZW5jZS90YWJzLyNldmVudC1vblVwZGF0ZWRcbiAgICBDaHJvbWVDYWxsYmFja3Mub25UYWJVcGRhdGVkID0gZnVuY3Rpb24gKHRhYklkLCBpbmZvKSB7XG4gICAgICAgIHZhciB0YWIgPSBUYWJDb250YWluZXJfMS50YWJDb250YWluZXIuZ2V0KHRhYklkKTtcbiAgICAgICAgaWYgKGluZm8ucGlubmVkICYmIHRhYikge1xuICAgICAgICAgICAgLy8gVGFiIHBpbm5lZCAtPiBwYXJlbnQgY2hpbGRyZW4gdG8gdGFiJ3MgcGFyZW50XG4gICAgICAgICAgICB0YWIuY2hpbGRyZW4uYXBwbHlBbGwoZnVuY3Rpb24gKGNoaWxkKSB7XG4gICAgICAgICAgICAgICAgY2hpbGQucGFyZW50VG8odGFiLnBhcmVudCk7XG4gICAgICAgICAgICAgICAgY2hpbGQucmVuZGVySW5kZW50YXRpb24oKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGFiLnBhcmVudFRvKHRhYi5nZXRXaW5kb3coKS5yb290KTtcbiAgICAgICAgICAgIC8vIFRPRE86IGZpeCBwcm9ibGVtcyB3aGVuIGFuIGludGVuZGVkIHRhYiBpcyBwaW5uZWRcbiAgICAgICAgfVxuICAgIH07XG4gICAgQ2hyb21lQ2FsbGJhY2tzLm9uV2luZG93Q3JlYXRlZCA9IGZ1bmN0aW9uIChjaHJvbWVXaW5kb3cpIHtcbiAgICAgICAgdmFyIHdpbmRvdyA9IFdpbmRvd18xLmRlZmF1bHQuaW5pdChjaHJvbWVXaW5kb3cpO1xuICAgICAgICAvLyBDb25uZWN0IG9ubHkgd2hlbiBuZWVkZWQgdG8gYXZvaWQgcmFjZSBjb25kaXRpb25zXG4gICAgICAgIC8vICh3aW5kb3cgaXMgbm90IHJlYWxseSB0byBwcm9jZXNzIG1lc3NhZ2luZyBpbW1lZGlhdGVseSlcbiAgICAgICAgLy8gd2luZG93LmNvbm5lY3QoKVxuICAgICAgICBXaW5kb3dDb250YWluZXJfMS53aW5kb3dDb250YWluZXIuYWRkKHdpbmRvdyk7XG4gICAgfTtcbiAgICBDaHJvbWVDYWxsYmFja3Mub25XaW5kb3dSZW1vdmVkID0gZnVuY3Rpb24gKHdpbmRvd0lkKSB7XG4gICAgICAgIHZhciB3aW5kb3cgPSBXaW5kb3dDb250YWluZXJfMS53aW5kb3dDb250YWluZXIuZ2V0KHdpbmRvd0lkKTtcbiAgICAgICAgV2luZG93Q29udGFpbmVyXzEud2luZG93Q29udGFpbmVyLnJlbW92ZSh3aW5kb3cpO1xuICAgIH07XG4gICAgcmV0dXJuIENocm9tZUNhbGxiYWNrcztcbn0oKSk7XG4vLyBJbml0aWFsaXplIHRhYiBhbmQgd2luZG93IGNvbnRhaW5lcnNcbmNocm9tZS53aW5kb3dzLmdldEFsbChXaW5kb3dDb250YWluZXJfMS53aW5kb3dDb250YWluZXIuaW5pdEZyb21BcnJheS5iaW5kKFdpbmRvd0NvbnRhaW5lcl8xLndpbmRvd0NvbnRhaW5lcikpO1xuY2hyb21lLnRhYnMucXVlcnkoe30sIFRhYkNvbnRhaW5lcl8xLnRhYkNvbnRhaW5lci5pbml0RnJvbUFycmF5LmJpbmQoVGFiQ29udGFpbmVyXzEudGFiQ29udGFpbmVyKSk7XG5jaHJvbWUudGFicy5vbkNyZWF0ZWQuYWRkTGlzdGVuZXIoQ2hyb21lQ2FsbGJhY2tzLm9uVGFiQ3JlYXRlZCk7XG5jaHJvbWUudGFicy5vbk1vdmVkLmFkZExpc3RlbmVyKENocm9tZUNhbGxiYWNrcy5vblRhYk1vdmVkKTtcbmNocm9tZS50YWJzLm9uUmVtb3ZlZC5hZGRMaXN0ZW5lcihDaHJvbWVDYWxsYmFja3Mub25UYWJSZW1vdmVkKTtcbmNocm9tZS50YWJzLm9uQXR0YWNoZWQuYWRkTGlzdGVuZXIoQ2hyb21lQ2FsbGJhY2tzLm9uVGFiQXR0YWNoZWQpO1xuY2hyb21lLnRhYnMub25EZXRhY2hlZC5hZGRMaXN0ZW5lcihDaHJvbWVDYWxsYmFja3Mub25UYWJEZXRhY2hlZCk7XG5jaHJvbWUudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoQ2hyb21lQ2FsbGJhY2tzLm9uVGFiVXBkYXRlZCk7XG5jaHJvbWUud2luZG93cy5vbkNyZWF0ZWQuYWRkTGlzdGVuZXIoQ2hyb21lQ2FsbGJhY2tzLm9uV2luZG93Q3JlYXRlZCk7XG5jaHJvbWUud2luZG93cy5vblJlbW92ZWQuYWRkTGlzdGVuZXIoQ2hyb21lQ2FsbGJhY2tzLm9uV2luZG93UmVtb3ZlZCk7XG5cblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL2FwcC9zY3JpcHRzL0luaXQudHNcbi8vIG1vZHVsZSBpZCA9IDlcbi8vIG1vZHVsZSBjaHVua3MgPSAwIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgX2Nocm9tZXJlbG9hZCA9IHJlcXVpcmUoJy4vY2hyb21lcmVsb2FkLmpzJyk7XG5cbnZhciBfY2hyb21lcmVsb2FkMiA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQoX2Nocm9tZXJlbG9hZCk7XG5cbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7IHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7IGRlZmF1bHQ6IG9iaiB9OyB9XG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ2RldmVsb3BtZW50Jykge1xuICBuZXcgX2Nocm9tZXJlbG9hZDIuZGVmYXVsdCgpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZGF0YTphcHBsaWNhdGlvbi9qc29uO2Jhc2U2NCxleUoyWlhKemFXOXVJam96TENKemIzVnlZMlZ6SWpwYkluTnlZeTlrWlhadmJteDVMbXB6SWwwc0ltNWhiV1Z6SWpwYkluQnliMk5sYzNNaUxDSmxibllpTENKT1QwUkZYMFZPVmlKZExDSnRZWEJ3YVc1bmN5STZJanM3UVVGQlFUczdPenM3TzBGQlJVRXNTVUZCU1VFc1VVRkJVVU1zUjBGQlVpeERRVUZaUXl4UlFVRmFMRXRCUVhsQ0xHRkJRVGRDTEVWQlFUUkRPMEZCUXpGRE8wRkJRMFFpTENKbWFXeGxJam9pWkdWMmIyNXNlUzVxY3lJc0luTnZkWEpqWlhORGIyNTBaVzUwSWpwYkltbHRjRzl5ZENCRGFISnZiV1ZTWld4dllXUWdabkp2YlNBbkxpOWphSEp2YldWeVpXeHZZV1F1YW5Nbk8xeHVYRzVwWmlBb2NISnZZMlZ6Y3k1bGJuWXVUazlFUlY5RlRsWWdQVDA5SUNka1pYWmxiRzl3YldWdWRDY3BJSHRjYmlBZ2JtVjNJRU5vY205dFpWSmxiRzloWkNncE8xeHVmVnh1SWwxOVxuXG5cbi8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gV0VCUEFDSyBGT09URVJcbi8vIC4vbm9kZV9tb2R1bGVzL2Nocm9tZXJlbG9hZC9kZXZvbmx5LmpzXG4vLyBtb2R1bGUgaWQgPSAxMFxuLy8gbW9kdWxlIGNodW5rcyA9IDAiLCIndXNlIHN0cmljdCc7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5cbnZhciBfY3JlYXRlQ2xhc3MgPSBmdW5jdGlvbiAoKSB7IGZ1bmN0aW9uIGRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBwcm9wcykgeyBmb3IgKHZhciBpID0gMDsgaSA8IHByb3BzLmxlbmd0aDsgaSsrKSB7IHZhciBkZXNjcmlwdG9yID0gcHJvcHNbaV07IGRlc2NyaXB0b3IuZW51bWVyYWJsZSA9IGRlc2NyaXB0b3IuZW51bWVyYWJsZSB8fCBmYWxzZTsgZGVzY3JpcHRvci5jb25maWd1cmFibGUgPSB0cnVlOyBpZiAoXCJ2YWx1ZVwiIGluIGRlc2NyaXB0b3IpIGRlc2NyaXB0b3Iud3JpdGFibGUgPSB0cnVlOyBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBkZXNjcmlwdG9yLmtleSwgZGVzY3JpcHRvcik7IH0gfSByZXR1cm4gZnVuY3Rpb24gKENvbnN0cnVjdG9yLCBwcm90b1Byb3BzLCBzdGF0aWNQcm9wcykgeyBpZiAocHJvdG9Qcm9wcykgZGVmaW5lUHJvcGVydGllcyhDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3RvUHJvcHMpOyBpZiAoc3RhdGljUHJvcHMpIGRlZmluZVByb3BlcnRpZXMoQ29uc3RydWN0b3IsIHN0YXRpY1Byb3BzKTsgcmV0dXJuIENvbnN0cnVjdG9yOyB9OyB9KCk7XG5cbmZ1bmN0aW9uIF9jbGFzc0NhbGxDaGVjayhpbnN0YW5jZSwgQ29uc3RydWN0b3IpIHsgaWYgKCEoaW5zdGFuY2UgaW5zdGFuY2VvZiBDb25zdHJ1Y3RvcikpIHsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvblwiKTsgfSB9XG5cbnZhciBDaHJvbWVSZWxvYWQgPSBmdW5jdGlvbiAoKSB7XG4gIGZ1bmN0aW9uIENocm9tZVJlbG9hZCgpIHtcbiAgICB2YXIgYXJncyA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMCB8fCBhcmd1bWVudHNbMF0gPT09IHVuZGVmaW5lZCA/IHt9IDogYXJndW1lbnRzWzBdO1xuXG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIENocm9tZVJlbG9hZCk7XG5cbiAgICB2YXIgX2FyZ3MkaG9zdCA9IGFyZ3MuaG9zdDtcbiAgICB2YXIgaG9zdCA9IF9hcmdzJGhvc3QgPT09IHVuZGVmaW5lZCA/ICdsb2NhbGhvc3QnIDogX2FyZ3MkaG9zdDtcbiAgICB2YXIgX2FyZ3MkcG9ydCA9IGFyZ3MucG9ydDtcbiAgICB2YXIgcG9ydCA9IF9hcmdzJHBvcnQgPT09IHVuZGVmaW5lZCA/IDM1NzI5IDogX2FyZ3MkcG9ydDtcbiAgICB2YXIgX2FyZ3MkcmVjb25uZWN0VGltZSA9IGFyZ3MucmVjb25uZWN0VGltZTtcbiAgICB2YXIgcmVjb25uZWN0VGltZSA9IF9hcmdzJHJlY29ubmVjdFRpbWUgPT09IHVuZGVmaW5lZCA/IDMwMDAgOiBfYXJncyRyZWNvbm5lY3RUaW1lO1xuICAgIHZhciBfYXJncyRkZWJ1ZyA9IGFyZ3MuZGVidWc7XG4gICAgdmFyIGRlYnVnID0gX2FyZ3MkZGVidWcgPT09IHVuZGVmaW5lZCA/IHRydWUgOiBfYXJncyRkZWJ1ZztcblxuXG4gICAgdGhpcy5ob3N0ID0gaG9zdDtcbiAgICB0aGlzLnBvcnQgPSBwb3J0O1xuICAgIHRoaXMucmVjb25uZWN0VGltZSA9IHJlY29ubmVjdFRpbWU7XG4gICAgdGhpcy5kZWJ1ZyA9IGRlYnVnO1xuXG4gICAgdGhpcy5jb25uZWN0ID0gdGhpcy5jb25uZWN0LmJpbmQodGhpcyk7XG4gICAgdGhpcy5vbmVycm9yID0gdGhpcy5vbmVycm9yLmJpbmQodGhpcyk7XG4gICAgdGhpcy5vbm9wZW4gPSB0aGlzLm9ub3Blbi5iaW5kKHRoaXMpO1xuICAgIHRoaXMuX29ubWVzc2FnZSA9IHRoaXMuX29ubWVzc2FnZS5iaW5kKHRoaXMpO1xuICAgIHRoaXMub25tZXNzYWdlID0gdGhpcy5vbm1lc3NhZ2UuYmluZCh0aGlzKTtcbiAgICB0aGlzLm9uY2xvc2UgPSB0aGlzLm9uY2xvc2UuYmluZCh0aGlzKTtcblxuICAgIHRoaXMuc3RhdGUgPSB7XG4gICAgICBjb25uZWN0ZWQ6IGZhbHNlLFxuICAgICAgY29ubmVjdGlvbkxvc3Q6IGZhbHNlLFxuICAgICAgcmVsb2FkaW5nOiBmYWxzZVxuICAgIH07XG5cbiAgICB0aGlzLmNvbm5lY3QoKTtcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhDaHJvbWVSZWxvYWQsIFt7XG4gICAga2V5OiAnY29ubmVjdCcsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNvbm5lY3QoKSB7XG4gICAgICB0aGlzLmNvbm5lY3Rpb24gPSBuZXcgV2ViU29ja2V0KCd3czovLycgKyB0aGlzLmhvc3QgKyAnOicgKyB0aGlzLnBvcnQgKyAnL2xpdmVyZWxvYWQnKTtcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5vbm9wZW4gPSB0aGlzLm9ub3BlbjtcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5vbm1lc3NhZ2UgPSB0aGlzLl9vbm1lc3NhZ2U7XG4gICAgICB0aGlzLmNvbm5lY3Rpb24ub25lcnJvciA9IHRoaXMub25lcnJvcjtcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5vbmNsb3NlID0gdGhpcy5vbmNsb3NlO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ29ub3BlbicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG9ub3BlbigpIHtcbiAgICAgIHRoaXMubG9nKCdFbmFibGVkJyk7XG4gICAgICB0aGlzLnN0YXRlLmNvbm5lY3RlZCA9IHRydWU7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnb25lcnJvcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG9uZXJyb3IoZXJyb3IpIHtcbiAgICAgIHRoaXMubG9nKCdDb25uZWN0aW9uIGVycm9yJyk7XG4gICAgICB0aGlzLnN0YXRlLmNvbm5lY3RlZCA9IGZhbHNlO1xuICAgICAgdGhpcy5zdGF0ZS5jb25uZWN0aW9uTG9zdCA9IHRydWU7XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnX29ubWVzc2FnZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIF9vbm1lc3NhZ2UoZXZlbnQpIHtcbiAgICAgIGlmIChldmVudC5kYXRhKSB7XG4gICAgICAgIHRoaXMub25tZXNzYWdlKEpTT04ucGFyc2UoZXZlbnQuZGF0YSkpO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ29ubWVzc2FnZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIG9ubWVzc2FnZShfcmVmKSB7XG4gICAgICB2YXIgY29tbWFuZCA9IF9yZWYuY29tbWFuZDtcbiAgICAgIHZhciBwYXRoID0gX3JlZi5wYXRoO1xuXG4gICAgICB2YXIgY29ubmVjdGlvbkxvc3QgPSB0aGlzLnN0YXRlLmNvbm5lY3Rpb25Mb3N0O1xuICAgICAgdmFyIHNjcmlwdHJlbG9hZCA9IC9cXC5qcyQvLnRlc3QocGF0aCk7XG5cbiAgICAgIGlmIChjb21tYW5kID09PSAncmVsb2FkJykge1xuXG4gICAgICAgIGlmIChjb25uZWN0aW9uTG9zdCAmJiAhc2NyaXB0cmVsb2FkKSB7XG4gICAgICAgICAgdGhpcy5sb2coJ1dhaXRpbmcgZm9yIHNjcmlwdHMgdG8gYmUgcmVhZHkuJyk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5zdGF0ZS5jb25uZWN0aW9uTG9zdCA9IGZhbHNlO1xuICAgICAgICB0aGlzLnJlbG9hZCgpO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ29uY2xvc2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBvbmNsb3NlKCkge1xuICAgICAgdGhpcy5sb2coJ0Nvbm5lY3Rpb24gbG9zdC4gUmVjb25uZWN0aW5nIGluICVzcycsIHRoaXMucmVjb25uZWN0VGltZSk7XG4gICAgICBzZXRUaW1lb3V0KHRoaXMuY29ubmVjdCwgdGhpcy5yZWNvbm5lY3RUaW1lKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdyZWxvYWQnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiByZWxvYWQoKSB7XG4gICAgICBpZiAodGhpcy5zdGF0ZS5yZWxvYWRpbmcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdGhpcy5zdGF0ZS5yZWxvYWRpbmcgPSB0cnVlO1xuICAgICAgdGhpcy5sb2coJ1JlbG9hZGluZyAuLi4nKTtcbiAgICAgIGlmIChjaHJvbWUucnVudGltZSAmJiBjaHJvbWUucnVudGltZS5yZWxvYWQpIHtcbiAgICAgICAgLy8gSWYgd2UgYXJlIG9uIGEgYmFja2dyb3VuZCBwYWdlXG4gICAgICAgIC8vIHdlIHNob3VsZCByZWxvYWQgdGhlIGVudGlyZSBydW50aW1lXG4gICAgICAgIGNocm9tZS5ydW50aW1lLnJlbG9hZCgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gU29tZXRpbWVzIHdlIGFyZSBvbiBhIGRpZmZlcmVudCBjb250ZXh0XG4gICAgICAgIC8vIGZvciBleGFtcGxlIGEgY29udGVudHNjcmlwdFxuICAgICAgICAvLyB0aGVyZWZvcmUgd2UgbmVlZCB0byByZWxvYWQgdmlhXG4gICAgICAgIC8vIHdpbmRvdy5sb2NhdGlvblxuICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAnbG9nJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gbG9nKG1lc3NhZ2UpIHtcbiAgICAgIGlmICh0aGlzLmRlYnVnKSB7XG4gICAgICAgIHZhciBfY29uc29sZTtcblxuICAgICAgICBmb3IgKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IEFycmF5KF9sZW4gPiAxID8gX2xlbiAtIDEgOiAwKSwgX2tleSA9IDE7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICAgICAgICBhcmdzW19rZXkgLSAxXSA9IGFyZ3VtZW50c1tfa2V5XTtcbiAgICAgICAgfVxuXG4gICAgICAgIChfY29uc29sZSA9IGNvbnNvbGUpLmxvZy5hcHBseShfY29uc29sZSwgWyclY0Nocm9tZVJlbG9hZDogJyArIG1lc3NhZ2UsICdjb2xvcjogZ3JheTsnXS5jb25jYXQoYXJncykpO1xuICAgICAgfVxuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBDaHJvbWVSZWxvYWQ7XG59KCk7XG5cbmV4cG9ydHMuZGVmYXVsdCA9IENocm9tZVJlbG9hZDtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRhdGE6YXBwbGljYXRpb24vanNvbjtiYXNlNjQsZXlKMlpYSnphVzl1SWpvekxDSnpiM1Z5WTJWeklqcGJJbk55WXk5amFISnZiV1Z5Wld4dllXUXVhbk1pWFN3aWJtRnRaWE1pT2xzaVEyaHliMjFsVW1Wc2IyRmtJaXdpWVhKbmN5SXNJbWh2YzNRaUxDSndiM0owSWl3aWNtVmpiMjV1WldOMFZHbHRaU0lzSW1SbFluVm5JaXdpWTI5dWJtVmpkQ0lzSW1KcGJtUWlMQ0p2Ym1WeWNtOXlJaXdpYjI1dmNHVnVJaXdpWDI5dWJXVnpjMkZuWlNJc0ltOXViV1Z6YzJGblpTSXNJbTl1WTJ4dmMyVWlMQ0p6ZEdGMFpTSXNJbU52Ym01bFkzUmxaQ0lzSW1OdmJtNWxZM1JwYjI1TWIzTjBJaXdpY21Wc2IyRmthVzVuSWl3aVkyOXVibVZqZEdsdmJpSXNJbGRsWWxOdlkydGxkQ0lzSW14dlp5SXNJbVZ5Y205eUlpd2laWFpsYm5RaUxDSmtZWFJoSWl3aVNsTlBUaUlzSW5CaGNuTmxJaXdpWTI5dGJXRnVaQ0lzSW5CaGRHZ2lMQ0p6WTNKcGNIUnlaV3h2WVdRaUxDSjBaWE4wSWl3aWNtVnNiMkZrSWl3aWMyVjBWR2x0Wlc5MWRDSXNJbU5vY205dFpTSXNJbkoxYm5ScGJXVWlMQ0ozYVc1a2IzY2lMQ0pzYjJOaGRHbHZiaUlzSW0xbGMzTmhaMlVpWFN3aWJXRndjR2x1WjNNaU9pSTdPenM3T3pzN096czdTVUZCVFVFc1dUdEJRVU5LTERCQ1FVRjFRanRCUVVGQkxGRkJRVmhETEVsQlFWY3NlVVJCUVVvc1JVRkJTVHM3UVVGQlFUczdRVUZCUVN4eFFrRk5ha0pCTEVsQlRtbENMRU5CUlc1Q1F5eEpRVVp0UWp0QlFVRkJMRkZCUlc1Q1FTeEpRVVp0UWl3NFFrRkZXaXhYUVVaWk8wRkJRVUVzY1VKQlRXcENSQ3hKUVU1cFFpeERRVWR1UWtVc1NVRkliVUk3UVVGQlFTeFJRVWR1UWtFc1NVRkliVUlzT0VKQlIxb3NTMEZJV1R0QlFVRkJMRGhDUVUxcVFrWXNTVUZPYVVJc1EwRkpia0pITEdGQlNtMUNPMEZCUVVFc1VVRkpia0pCTEdGQlNtMUNMSFZEUVVsSUxFbEJTa2M3UVVGQlFTeHpRa0ZOYWtKSUxFbEJUbWxDTEVOQlMyNUNTU3hMUVV4dFFqdEJRVUZCTEZGQlMyNUNRU3hMUVV4dFFpd3JRa0ZMV0N4SlFVeFhPenM3UVVGUmNrSXNVMEZCUzBnc1NVRkJUQ3hIUVVGWlFTeEpRVUZhTzBGQlEwRXNVMEZCUzBNc1NVRkJUQ3hIUVVGWlFTeEpRVUZhTzBGQlEwRXNVMEZCUzBNc1lVRkJUQ3hIUVVGeFFrRXNZVUZCY2tJN1FVRkRRU3hUUVVGTFF5eExRVUZNTEVkQlFXRkJMRXRCUVdJN08wRkJSVUVzVTBGQlMwTXNUMEZCVEN4SFFVRmxMRXRCUVV0QkxFOUJRVXdzUTBGQllVTXNTVUZCWWl4RFFVRnJRaXhKUVVGc1FpeERRVUZtTzBGQlEwRXNVMEZCUzBNc1QwRkJUQ3hIUVVGbExFdEJRVXRCTEU5QlFVd3NRMEZCWVVRc1NVRkJZaXhEUVVGclFpeEpRVUZzUWl4RFFVRm1PMEZCUTBFc1UwRkJTMFVzVFVGQlRDeEhRVUZqTEV0QlFVdEJMRTFCUVV3c1EwRkJXVVlzU1VGQldpeERRVUZwUWl4SlFVRnFRaXhEUVVGa08wRkJRMEVzVTBGQlMwY3NWVUZCVEN4SFFVRnJRaXhMUVVGTFFTeFZRVUZNTEVOQlFXZENTQ3hKUVVGb1FpeERRVUZ4UWl4SlFVRnlRaXhEUVVGc1FqdEJRVU5CTEZOQlFVdEpMRk5CUVV3c1IwRkJhVUlzUzBGQlMwRXNVMEZCVEN4RFFVRmxTaXhKUVVGbUxFTkJRVzlDTEVsQlFYQkNMRU5CUVdwQ08wRkJRMEVzVTBGQlMwc3NUMEZCVEN4SFFVRmxMRXRCUVV0QkxFOUJRVXdzUTBGQllVd3NTVUZCWWl4RFFVRnJRaXhKUVVGc1FpeERRVUZtT3p0QlFVVkJMRk5CUVV0TkxFdEJRVXdzUjBGQllUdEJRVU5ZUXl4cFFrRkJWeXhMUVVSQk8wRkJSVmhETEhOQ1FVRm5RaXhMUVVaTU8wRkJSMWhETEdsQ1FVRlhPMEZCU0VFc1MwRkJZanM3UVVGTlFTeFRRVUZMVml4UFFVRk1PMEZCUTBRN096czdPRUpCUlZNN1FVRkRVaXhYUVVGTFZ5eFZRVUZNTEVkQlFXdENMRWxCUVVsRExGTkJRVW9zVjBGQmMwSXNTMEZCUzJoQ0xFbEJRVE5DTEZOQlFXMURMRXRCUVV0RExFbEJRWGhETEdsQ1FVRnNRanRCUVVOQkxGZEJRVXRqTEZWQlFVd3NRMEZCWjBKU0xFMUJRV2hDTEVkQlFYbENMRXRCUVV0QkxFMUJRVGxDTzBGQlEwRXNWMEZCUzFFc1ZVRkJUQ3hEUVVGblFrNHNVMEZCYUVJc1IwRkJORUlzUzBGQlMwUXNWVUZCYWtNN1FVRkRRU3hYUVVGTFR5eFZRVUZNTEVOQlFXZENWQ3hQUVVGb1FpeEhRVUV3UWl4TFFVRkxRU3hQUVVFdlFqdEJRVU5CTEZkQlFVdFRMRlZCUVV3c1EwRkJaMEpNTEU5QlFXaENMRWRCUVRCQ0xFdEJRVXRCTEU5QlFTOUNPMEZCUTBRN096czJRa0ZGVVR0QlFVTlFMRmRCUVV0UExFZEJRVXdzUTBGQlV5eFRRVUZVTzBGQlEwRXNWMEZCUzA0c1MwRkJUQ3hEUVVGWFF5eFRRVUZZTEVkQlFYVkNMRWxCUVhaQ08wRkJRMFE3T3pzMFFrRkZUMDBzU3l4RlFVRlBPMEZCUTJJc1YwRkJTMFFzUjBGQlRDeERRVUZUTEd0Q1FVRlVPMEZCUTBFc1YwRkJTMDRzUzBGQlRDeERRVUZYUXl4VFFVRllMRWRCUVhWQ0xFdEJRWFpDTzBGQlEwRXNWMEZCUzBRc1MwRkJUQ3hEUVVGWFJTeGpRVUZZTEVkQlFUUkNMRWxCUVRWQ08wRkJRMFE3T3pzclFrRkZWVTBzU3l4RlFVRlBPMEZCUTJoQ0xGVkJRVWxCTEUxQlFVMURMRWxCUVZZc1JVRkJaMEk3UVVGRFpDeGhRVUZMV0N4VFFVRk1MRU5CUTBWWkxFdEJRVXRETEV0QlFVd3NRMEZCVjBnc1RVRkJUVU1zU1VGQmFrSXNRMEZFUmp0QlFVZEVPMEZCUTBZN096dHZRMEZMUlR0QlFVRkJMRlZCUmtSSExFOUJSVU1zVVVGR1JFRXNUMEZGUXp0QlFVRkJMRlZCUkVSRExFbEJRME1zVVVGRVJFRXNTVUZEUXpzN1FVRkRSQ3hWUVVGTldDeHBRa0ZCYVVJc1MwRkJTMFlzUzBGQlRDeERRVUZYUlN4alFVRnNRenRCUVVOQkxGVkJRVTFaTEdWQlFXVXNVVUZCVVVNc1NVRkJVaXhEUVVGaFJpeEpRVUZpTEVOQlFYSkNPenRCUVVWQkxGVkJRVWxFTEZsQlFWa3NVVUZCYUVJc1JVRkJNRUk3TzBGQlJYaENMRmxCUVVsV0xHdENRVUZyUWl4RFFVRkRXU3haUVVGMlFpeEZRVUZ4UXp0QlFVTnVReXhsUVVGTFVpeEhRVUZNTEVOQlFWTXNhME5CUVZRN1FVRkRRVHRCUVVORU96dEJRVVZFTEdGQlFVdE9MRXRCUVV3c1EwRkJWMFVzWTBGQldDeEhRVUUwUWl4TFFVRTFRanRCUVVOQkxHRkJRVXRqTEUxQlFVdzdRVUZEUkR0QlFVTkdPenM3T0VKQlJWTTdRVUZEVWl4WFFVRkxWaXhIUVVGTUxFTkJRVk1zYzBOQlFWUXNSVUZCYVVRc1MwRkJTMllzWVVGQmRFUTdRVUZEUVRCQ0xHbENRVUZYTEV0QlFVdDRRaXhQUVVGb1FpeEZRVUY1UWl4TFFVRkxSaXhoUVVFNVFqdEJRVU5FT3pzN05rSkJSVkU3UVVGRFVDeFZRVUZKTEV0QlFVdFRMRXRCUVV3c1EwRkJWMGNzVTBGQlppeEZRVUV3UWp0QlFVTjRRanRCUVVORU8wRkJRMFFzVjBGQlMwZ3NTMEZCVEN4RFFVRlhSeXhUUVVGWUxFZEJRWFZDTEVsQlFYWkNPMEZCUTBFc1YwRkJTMGNzUjBGQlRDeERRVUZUTEdWQlFWUTdRVUZEUVN4VlFVRkpXU3hQUVVGUFF5eFBRVUZRTEVsQlFXdENSQ3hQUVVGUFF5eFBRVUZRTEVOQlFXVklMRTFCUVhKRExFVkJRVFpETzBGQlF6TkRPMEZCUTBFN1FVRkRRVVVzWlVGQlQwTXNUMEZCVUN4RFFVRmxTQ3hOUVVGbU8wRkJRMFFzVDBGS1JDeE5RVWxQTzBGQlEwdzdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVWtzWlVGQlQwTXNVVUZCVUN4RFFVRm5Ra3dzVFVGQmFFSTdRVUZEUkR0QlFVTkdPenM3ZDBKQlJVZE5MRThzUlVGQmEwSTdRVUZEY0VJc1ZVRkJSeXhMUVVGTE9VSXNTMEZCVWl4RlFVRmxPMEZCUVVFN08wRkJRVUVzTUVOQlJFUktMRWxCUTBNN1FVRkVSRUVzWTBGRFF6dEJRVUZCT3p0QlFVTmlMRFpDUVVGUmEwSXNSMEZCVWl4MVEwRkJLMEpuUWl4UFFVRXZRaXhGUVVFd1F5eGpRVUV4UXl4VFFVRTJSR3hETEVsQlFUZEVPMEZCUTBRN1FVRkRSanM3T3pzN08ydENRVWRaUkN4Wklpd2labWxzWlNJNkltTm9jbTl0WlhKbGJHOWhaQzVxY3lJc0luTnZkWEpqWlhORGIyNTBaVzUwSWpwYkltTnNZWE56SUVOb2NtOXRaVkpsYkc5aFpDQjdYRzRnSUdOdmJuTjBjblZqZEc5eUtHRnlaM01nUFNCN2ZTa2dlMXh1SUNBZ0lHTnZibk4wSUh0Y2JpQWdJQ0FnSUdodmMzUWdQU0FuYkc5allXeG9iM04wSnl4Y2JpQWdJQ0FnSUhCdmNuUWdQU0F6TlRjeU9TeGNiaUFnSUNBZ0lISmxZMjl1Ym1WamRGUnBiV1VnUFNBek1EQXdMRnh1SUNBZ0lDQWdaR1ZpZFdjZ1BTQjBjblZsWEc0Z0lDQWdmU0E5SUdGeVozTTdYRzVjYmlBZ0lDQjBhR2x6TG1odmMzUWdQU0JvYjNOME8xeHVJQ0FnSUhSb2FYTXVjRzl5ZENBOUlIQnZjblE3WEc0Z0lDQWdkR2hwY3k1eVpXTnZibTVsWTNSVWFXMWxJRDBnY21WamIyNXVaV04wVkdsdFpUdGNiaUFnSUNCMGFHbHpMbVJsWW5WbklEMGdaR1ZpZFdjN1hHNWNiaUFnSUNCMGFHbHpMbU52Ym01bFkzUWdQU0IwYUdsekxtTnZibTVsWTNRdVltbHVaQ2gwYUdsektUdGNiaUFnSUNCMGFHbHpMbTl1WlhKeWIzSWdQU0IwYUdsekxtOXVaWEp5YjNJdVltbHVaQ2gwYUdsektUdGNiaUFnSUNCMGFHbHpMbTl1YjNCbGJpQTlJSFJvYVhNdWIyNXZjR1Z1TG1KcGJtUW9kR2hwY3lrN1hHNGdJQ0FnZEdocGN5NWZiMjV0WlhOellXZGxJRDBnZEdocGN5NWZiMjV0WlhOellXZGxMbUpwYm1Rb2RHaHBjeWs3WEc0Z0lDQWdkR2hwY3k1dmJtMWxjM05oWjJVZ1BTQjBhR2x6TG05dWJXVnpjMkZuWlM1aWFXNWtLSFJvYVhNcE8xeHVJQ0FnSUhSb2FYTXViMjVqYkc5elpTQTlJSFJvYVhNdWIyNWpiRzl6WlM1aWFXNWtLSFJvYVhNcE8xeHVYRzRnSUNBZ2RHaHBjeTV6ZEdGMFpTQTlJSHRjYmlBZ0lDQWdJR052Ym01bFkzUmxaRG9nWm1Gc2MyVXNYRzRnSUNBZ0lDQmpiMjV1WldOMGFXOXVURzl6ZERvZ1ptRnNjMlVzWEc0Z0lDQWdJQ0J5Wld4dllXUnBibWM2SUdaaGJITmxYRzRnSUNBZ2ZUdGNibHh1SUNBZ0lIUm9hWE11WTI5dWJtVmpkQ2dwTzF4dUlDQjlYRzVjYmlBZ1kyOXVibVZqZENncElIdGNiaUFnSUNCMGFHbHpMbU52Ym01bFkzUnBiMjRnUFNCdVpYY2dWMlZpVTI5amEyVjBLR0IzY3pvdkx5UjdkR2hwY3k1b2IzTjBmVG9rZTNSb2FYTXVjRzl5ZEgwdmJHbDJaWEpsYkc5aFpHQXBPMXh1SUNBZ0lIUm9hWE11WTI5dWJtVmpkR2x2Ymk1dmJtOXdaVzRnUFNCMGFHbHpMbTl1YjNCbGJqdGNiaUFnSUNCMGFHbHpMbU52Ym01bFkzUnBiMjR1YjI1dFpYTnpZV2RsSUQwZ2RHaHBjeTVmYjI1dFpYTnpZV2RsTzF4dUlDQWdJSFJvYVhNdVkyOXVibVZqZEdsdmJpNXZibVZ5Y205eUlEMGdkR2hwY3k1dmJtVnljbTl5TzF4dUlDQWdJSFJvYVhNdVkyOXVibVZqZEdsdmJpNXZibU5zYjNObElEMGdkR2hwY3k1dmJtTnNiM05sTzF4dUlDQjlYRzVjYmlBZ2IyNXZjR1Z1S0NrZ2UxeHVJQ0FnSUhSb2FYTXViRzluS0NkRmJtRmliR1ZrSnlrN1hHNGdJQ0FnZEdocGN5NXpkR0YwWlM1amIyNXVaV04wWldRZ1BTQjBjblZsTzF4dUlDQjlYRzVjYmlBZ2IyNWxjbkp2Y2lobGNuSnZjaWtnZTF4dUlDQWdJSFJvYVhNdWJHOW5LQ2REYjI1dVpXTjBhVzl1SUdWeWNtOXlKeWs3WEc0Z0lDQWdkR2hwY3k1emRHRjBaUzVqYjI1dVpXTjBaV1FnUFNCbVlXeHpaVHRjYmlBZ0lDQjBhR2x6TG5OMFlYUmxMbU52Ym01bFkzUnBiMjVNYjNOMElEMGdkSEoxWlR0Y2JpQWdmVnh1WEc0Z0lGOXZibTFsYzNOaFoyVW9aWFpsYm5RcElIdGNiaUFnSUNCcFppQW9aWFpsYm5RdVpHRjBZU2tnZTF4dUlDQWdJQ0FnZEdocGN5NXZibTFsYzNOaFoyVW9YRzRnSUNBZ0lDQWdJRXBUVDA0dWNHRnljMlVvWlhabGJuUXVaR0YwWVNsY2JpQWdJQ0FnSUNrN1hHNGdJQ0FnZlZ4dUlDQjlYRzVjYmlBZ2IyNXRaWE56WVdkbEtIdGNiaUFnSUNCamIyMXRZVzVrTEZ4dUlDQWdJSEJoZEdoY2JpQWdmU2tnZTF4dUlDQWdJR052Ym5OMElHTnZibTVsWTNScGIyNU1iM04wSUQwZ2RHaHBjeTV6ZEdGMFpTNWpiMjV1WldOMGFXOXVURzl6ZER0Y2JpQWdJQ0JqYjI1emRDQnpZM0pwY0hSeVpXeHZZV1FnUFNBdlhGd3Vhbk1rTHk1MFpYTjBLSEJoZEdncE8xeHVYRzRnSUNBZ2FXWWdLR052YlcxaGJtUWdQVDA5SUNkeVpXeHZZV1FuS1NCN1hHNWNiaUFnSUNBZ0lHbG1JQ2hqYjI1dVpXTjBhVzl1VEc5emRDQW1KaUFoYzJOeWFYQjBjbVZzYjJGa0tTQjdYRzRnSUNBZ0lDQWdJSFJvYVhNdWJHOW5LQ2RYWVdsMGFXNW5JR1p2Y2lCelkzSnBjSFJ6SUhSdklHSmxJSEpsWVdSNUxpY3BPMXh1SUNBZ0lDQWdJQ0J5WlhSMWNtNDdYRzRnSUNBZ0lDQjlYRzVjYmlBZ0lDQWdJSFJvYVhNdWMzUmhkR1V1WTI5dWJtVmpkR2x2Ymt4dmMzUWdQU0JtWVd4elpUdGNiaUFnSUNBZ0lIUm9hWE11Y21Wc2IyRmtLQ2s3WEc0Z0lDQWdmVnh1SUNCOVhHNWNiaUFnYjI1amJHOXpaU2dwSUh0Y2JpQWdJQ0IwYUdsekxteHZaeWduUTI5dWJtVmpkR2x2YmlCc2IzTjBMaUJTWldOdmJtNWxZM1JwYm1jZ2FXNGdKWE56Snl3Z2RHaHBjeTV5WldOdmJtNWxZM1JVYVcxbEtUdGNiaUFnSUNCelpYUlVhVzFsYjNWMEtIUm9hWE11WTI5dWJtVmpkQ3dnZEdocGN5NXlaV052Ym01bFkzUlVhVzFsS1R0Y2JpQWdmVnh1WEc0Z0lISmxiRzloWkNncElIdGNiaUFnSUNCcFppQW9kR2hwY3k1emRHRjBaUzV5Wld4dllXUnBibWNwSUh0Y2JpQWdJQ0FnSUhKbGRIVnlianRjYmlBZ0lDQjlYRzRnSUNBZ2RHaHBjeTV6ZEdGMFpTNXlaV3h2WVdScGJtY2dQU0IwY25WbE8xeHVJQ0FnSUhSb2FYTXViRzluS0NkU1pXeHZZV1JwYm1jZ0xpNHVKeWs3WEc0Z0lDQWdhV1lnS0dOb2NtOXRaUzV5ZFc1MGFXMWxJQ1ltSUdOb2NtOXRaUzV5ZFc1MGFXMWxMbkpsYkc5aFpDa2dlMXh1SUNBZ0lDQWdMeThnU1dZZ2QyVWdZWEpsSUc5dUlHRWdZbUZqYTJkeWIzVnVaQ0J3WVdkbFhHNGdJQ0FnSUNBdkx5QjNaU0J6YUc5MWJHUWdjbVZzYjJGa0lIUm9aU0JsYm5ScGNtVWdjblZ1ZEdsdFpWeHVJQ0FnSUNBZ1kyaHliMjFsTG5KMWJuUnBiV1V1Y21Wc2IyRmtLQ2s3WEc0Z0lDQWdmU0JsYkhObElIdGNiaUFnSUNBZ0lDOHZJRk52YldWMGFXMWxjeUIzWlNCaGNtVWdiMjRnWVNCa2FXWm1aWEpsYm5RZ1kyOXVkR1Y0ZEZ4dUlDQWdJQ0FnTHk4Z1ptOXlJR1Y0WVcxd2JHVWdZU0JqYjI1MFpXNTBjMk55YVhCMFhHNGdJQ0FnSUNBdkx5QjBhR1Z5WldadmNtVWdkMlVnYm1WbFpDQjBieUJ5Wld4dllXUWdkbWxoWEc0Z0lDQWdJQ0F2THlCM2FXNWtiM2N1Ykc5allYUnBiMjVjYmlBZ0lDQWdJSGRwYm1SdmR5NXNiMk5oZEdsdmJpNXlaV3h2WVdRb0tUdGNiaUFnSUNCOVhHNGdJSDFjYmx4dUlDQnNiMmNvYldWemMyRm5aU3dnTGk0dVlYSm5jeWtnZTF4dUlDQWdJR2xtS0hSb2FYTXVaR1ZpZFdjcElIdGNiaUFnSUNBZ0lHTnZibk52YkdVdWJHOW5LR0FsWTBOb2NtOXRaVkpsYkc5aFpEb2dKSHR0WlhOellXZGxmV0FzSUNkamIyeHZjam9nWjNKaGVUc25MQ0F1TGk1aGNtZHpLVHRjYmlBZ0lDQjlYRzRnSUgxY2JuMWNibHh1Wlhod2IzSjBJR1JsWm1GMWJIUWdRMmh5YjIxbFVtVnNiMkZrTzF4dUlsMTlcblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyAuL25vZGVfbW9kdWxlcy9jaHJvbWVyZWxvYWQvY2hyb21lcmVsb2FkLmpzXG4vLyBtb2R1bGUgaWQgPSAxMVxuLy8gbW9kdWxlIGNodW5rcyA9IDAiXSwic291cmNlUm9vdCI6IiJ9