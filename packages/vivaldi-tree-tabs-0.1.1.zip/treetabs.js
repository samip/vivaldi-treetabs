class Messaging {
  constructor (port, uiControl) {
    this.uiControl = uiControl
    this.port = port
    this.alwaysRespond = true

    if (port) {
      this.port.onDisconnect.addListener(x => console.log('Disconnect', x))
      this.port.onMessage.addListener(this.onReceived.bind(this))
      this.port.postMessage('Moro ' + this.port.name)
    } else {
      throw new treeTabUserScriptError('Invalid port')
    }

  }

  // Handle incoming command
  onReceived (request, port) {
    let reply = 'ACK'

    switch (request.command) {
      // Indents tab by <indentLevel> steps.
      // @param tabId
      // @param indentLevel - how many steps tab needs to be indentedx
      case 'IndentTab':
        this.uiControl.tab(request.tabId).indentTab(request.indentLevel)
        break


      // Show or create 'Close child tabs' button in tab strip
      // @param TabId
      //
      case 'ShowCloseChildrenButton':
        this.uiControl.tab(request.tabId).showCloseChildrenButton()
        break

      //  Hide 'Close child tabs' button in tab strip
      // @param TabId
      case 'HideCloseChildrenButton':
        this.uiControl.tab(request.tabId).hideCloseChildrenButton()
        break
      default:
        reply = 'NACK'
        console.error('Invalid command: ' + request.command)
        console.log(request)
        break
    }
    if (this.alwaysRespond) {
      this.send(reply)
    }
  }

  send (msg) {
    if (this.port) {
      this.port.postMessage(msg)
    } else {
      console.error('Trying to send message without connection', msg)
    }
    if (chrome.runtime.lastError) {
      console.log(chrome.runtime.lastError)
    }
  }
}

class TabCommand {

  constructor (tabId, element) {
    this.tabId = tabId
    this.element = element
    this.queue = []
  }

  setMessagingFunction (messagingFunction) {
    // Used to send messages to the extension
    // usage: this.messagingFunction({command: 'closeChildTabs', tabId: 5})
    this.messagingFunction = messagingFunction
  }

  setElement (element) {
    this.element = element
    return this
  }

  runQueuedCommands (_element) {
    const queuedCommands = []

    while (this.queue.length) {
      let cmd = this.queue.shift()
      this[cmd.command](cmd.args)
      queuedCommands.push(cmd)
    }
    return queuedCommands
  }

  queueCommand (command, args) {
    const argsArray = []
    for (let i = 0; i < args.length; i++) {
      argsArray.push(args[i])
    }
    this.queue.push({
      command: command,
      args: argsArray
    })
    return this
  }

  messagingFunctionValid () {
    console.log(this.messagingFunction)
    return this.messagingFunction && typeof this.messagingFunction === 'function'
  }

  // --------------
  // Tab UI methods
  // --------------

  indentTab (indentLevel) {
    if (!this.element) {
      return this.queueCommand('indentTab', arguments)
    }

    const indentVal = (indentLevel * this.indentationOption('step')) + this.indentationOption('unit')

    if (this.element.parentElement) {
      // Setting tab elements parents's padding-left works well as of 14.2.2021
      this.element.parentElement.style[this.indentationOption('attribute')] = indentVal
    }
  }

  indentationOption (key) {
    const options = {
      step: 15,
      unit: 'px',
      attribute: 'paddingLeft'
    }
    return options[key]
  }

  showCloseChildrenButton () {
    if (!this.messagingFunctionValid()) {
      // console.error('Skipping showCloseChildrenButton... invalid messageFunction')
      // return this
    }

    if (!this.element) {
      return this.queueCommand('showCloseChildrenButton', arguments)
    }

    const closeButton = this.element.querySelector('.close')
    const buttonClass = 'close-children'
    const existingButton = this.element.querySelector('.' + buttonClass)

    if (existingButton) {
      existingButton.style.visibility = 'initial'
      return this
    }

    const closeChildrenButton = document.createElement('button')
    closeChildrenButton.title = 'Close child tabs'
    closeChildrenButton.classList.add('close')
    closeChildrenButton.classList.add(buttonClass)
    closeChildrenButton.innerHTML = TabCommand.getCloseChildrenButtonSVG()

    closeChildrenButton.addEventListener('click', (_event) => {
      // this.messagingFunction({command: 'CloseChildren', tabId: this.tabId})
      window.messaing.send({command: 'CloseChildren', tabId: this.tabID})
    })
    closeButton.parentNode.insertBefore(closeChildrenButton, closeButton)
    return this
  }

  hideCloseChildrenButton () {
    if (!this.element) {
      return this.queueCommand('hideCloseChildrenButton', arguments)
    }
    const buttonClass = 'close-children'
    const closeChildrenButton = this.element.querySelector('.' + buttonClass)
    if (closeChildrenButton) {
      closeChildrenButton.style.visibility = 'hidden'
    }
    return this
  }

  // icon for close children button. Vivaldi's close tab icon + three circles
  static getCloseChildrenButtonSVG () {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
            <path d="M13.5 6l-1.4-1.4-3.1 3-3.1-3L4.5 6l3.1 3.1-3 2.9 1.5 1.4L9 10.5l2.9 2.9 1.5-1.4-3-2.9"></path>
            <circle
             cx="5.5"
             cy="15.8"
             r="1.5" />
            <circle
             cx="9"
             cy="15.8"
             r="1.5" />
            <circle
             cx="12.394068"
             cy="15.8"
             r="1.5" />
          </svg>`
  }

}


/*
const observer = new UIObserver()
observer.tabContainer.addCallback('onCreated', function(element))
observer.tab.addCallback('onCreated', function(element))
*/

class UIObserver {

  static tabContainerElementId = 'tabs-tabbar-container'

  constructor() {
    this.tabContainerObserver = null
    this.tabObserver = null

    const addCallback = function(eventName, fn) {
      this.eventHandlers[eventName].push(fn)
    }

    this.tab = {
      eventHandlers: {
        onCreated: [] // function(tabElement, tabId)
      },
      addCallback: addCallback
    }

    this.tabContainer = {
      eventHandlers: {
        onCreated: [], // function(tabContainerElement)
        onRemoved: []  // function(tabContainerElement)
      },
      addCallback: addCallback
    }
  }

  init() {
    waitForElement('#main > .inner', 5000)
      .then(tabContainerParent => {
          this.initTabContainerObserver(tabContainerParent)
          const tabContainer = this.findTabContainerFromDocument()
          tabContainer && this.onTabContainerCreated(tabContainer)
        },
        error => console.error(error)
      )
  }

  initTabContainerObserver(tabContainerParent) {
    this.tabContainerObserver = new MutationObserver(this.findTabContainerFromMutations.bind(this))
    this.tabContainerObserver.observe(tabContainerParent, {
      attributes: false,
      childList: true,
      characterData: false
    })
  }

  initTabObserver(tabStripElement) {
    this.tabObserver = new MutationObserver(this.findTabsFromMutations.bind(this))
    this.tabObserver.observe(tabStripElement, {
      attributes: false,
      childList: true,
      characterData: false
    })
  }

  onTabContainerCreated(tabContainerElement) {
    this.tabContainer.eventHandlers['onCreated'].forEach(eventHandler => eventHandler(tabContainerElement))

    // TODO: avoid searching whole document, use tabContainerElement instead
    waitForElement('.tab-strip', 5000)
      .then(
        element => this.initTabObserver(element),
        error => console.error(error)
      )
  }

  onTabContainerRemoved(tabContainerElement) {
    this.tabContainer.eventHandlers['onRemoved'].forEach(eventHandler => eventHandler(tabContainerElement))
  }

  onTabCreated(tabElement)  {
    const getTabId = node => {
      // eg. <div class="tab" id="tab-15">
      const idParts = node.id.split('-')
      return (idParts.length === 2) ? parseInt(idParts[1]) : null
    }

    const id = getTabId(tabElement)
    id && this.tab.eventHandlers.onCreated.forEach(eventHandler => eventHandler(tabElement, id))
  }

  /*
  -------------------
  | Finder methods
  -------------------
  */

  findTabContainerFromMutations(mutations) {
    const isTabContainer = node => node.id === UIObserver.tabContainerElementId

    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        isTabContainer(node)
        this.onTabContainerCreated(node)
      })

      mutation.removedNodes.forEach(node => {
        isTabContainer(node)
        this.onTabContainerRemoved(node)
      })
    })
  }

  findTabContainerFromDocument() {
    return document.getElementById(UIObserver.tabContainerElementId)
  }

  findTabsFromMutations(mutations) {
    const findTabDiv = node => node.querySelector('.tab')

    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        const tabDiv = findTabDiv(node)
        tabDiv && this.onTabCreated(tabDiv)
      })
    })
  }
}


function waitForElement(selector, rejectAfterMs) {
  return new Promise((resolve, reject) => {
    let element = document.querySelector(selector)
    if (element) {
      resolve(element)
    }

    const retryTime = 100
    let totalPollTime = 0

    setInterval(() => {
      element = document.querySelector(selector)
      if (element) {
        resolve(element)
      } else {
        totalPollTime += retryTime
        if (totalPollTime >= rejectAfterMs) {
          reject(`${selector} did not resolve in ${rejectAfterMs} ms`)
        }
      }
    }, retryTime)
  });
}


class UIController {

  constructor () {
    this.tabs = {}
    this.messagingFunction = null
  }

  setMessagingFunction (messagingFunction) {
    this.messagingFunction = messagingFunction
  }

  tab (tabId) {
    if (!this.tabs[tabId]) {
      this.tabs[tabId] = new TabCommand(tabId, this.getElement(tabId))
      this.tabs[tabId].setMessagingFunction(this.messagingFunction)
    } else {
      this.tabs[tabId].setElement(this.getElement(tabId))
    }

    return this.tabs[tabId]
  }

  showRefreshViewButton () {
    const buttonId = 'refresh-tab-tree'
    // Busted
    const existing = document.getElementById(buttonId)
    if (existing) {
      return this
    }

    const target = document.querySelector('#tabs-container > .toolbar')
    const button = document.createElement('button')

    button.innerText = 'Refresh'
    button.id = 'refresh-tab-tree'
    button.classList = 'button-toolbar refresh-tab-tree'

    button.addEventListener('click', (_event) => {
      this.messagingFunction({ command: 'RenderAllTabs' })
    })

    target.appendChild(button)
    return this
  }

  getElement (tabId) {
    return document.getElementById('tab-' + tabId)
  }

}

function log(...args) {
  messaging.send(...args)
}

function initTreeTabUserScript(messagingPort) {
  console.log('https://github.com/samip/vivaldi-treetabs user script initialized')
  window.uiControl = new UIController()
  window.messaging = new Messaging(messagingPort, window.uiControl)

  window.vivaldiUI = new UIObserver()
  window.uiControl.setMessagingFunction(msg => window.messaging.send(msg))
  window.vivaldiUI.tabContainer.addCallback('onCreated', (element) => {
    // Tab container is removed when browser enters full screen mode
    // and is rendered again when exiting full screen mode.
    // Ask extension to re-render tab indentantions after Tab container is created.
    window.messaging.send({command: 'RenderAllTabs'})
    window.uiControl.showRefreshViewButton()
  })

  window.vivaldiUI.tab.addCallback('onCreated', (element, tabId) => {
    // Commands were given to tab from extension before tab element
    // was rendered in UI, run them now.
    window.uiControl.tab(tabId).setElement(element)
    window.uiControl.tab(tabId).runQueuedCommands(element)
  })

  window.vivaldiUI.init()

  window.messaging = messaging
  window.vivaldiUI = vivaldiUI
  window.uiControl = uiControl
}

class treeTabUserScriptError extends Error {
  constructor(message) {
    super(message)
    this.name = 'treeTabUserScriptError'
  }
}

chrome.runtime.onConnectExternal.addListener(port => {
  const windowId = window.vivaldiWindowId
  if (port.name === 'window-' + windowId) {
    console.info('Messaging port for new window', port.name)
    initTreeTabUserScript(port)
  }
})
